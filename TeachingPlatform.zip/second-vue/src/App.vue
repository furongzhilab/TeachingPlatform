<template>
  <div id="app">
    <router-view/>
    <loading></loading>
  </div>
</template>
<script>
import loading from "./views/loading";
export default {
  name: 'App',
  components: {loading}
}
</script>
<style>
</style>
