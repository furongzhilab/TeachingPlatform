<template>
<!--直播社区-->
  <el-container style="height: 100%; margin: fill;">
    <!--####################################################################################################################-->
    <!--头部导航栏-->
    <el-header style="height: 80px;">
      <div style="width:230px; position: absolute;">
        <a href="" title="名师有享">
          <img src="../assets/img/logo05.png" width="220px" height="70px">
        </a>
      </div>
      <div style="position: absolute;margin-left: 270px;margin-top: 0px;">
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px;">
          <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
          <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px;">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item divided>
                <strong>小学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>编程</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>中学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>高中课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <el-link @click="teacherteam" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
          <el-link @click="livecommunity" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
          <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
          <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
          <el-input
              style="width: 230px; height: 100px; margin-left: 130px; margin-top: 10px"
              placeholder="请输入内容"
              v-model="input">
            <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
            <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
          </el-input>
          <el-link target="_blank" @click="login" style="margin-left: 30px">登录</el-link>
          <a style="margin-left: 5px"> | </a>
          <el-link target="_blank" style="margin-left: 5px">注册</el-link>
        </el-tabs>
      </div>
    </el-header>

<!--####################################################################################################################-->
    <!--内容-->
    <el-main style="background: #F0F0F0;">
      <!--（1）-->
      <div>
        <div style="font-family: 微软雅黑;font-size: 20pt;margin-left: 10px;margin-top: 10px">
          直播推荐
        </div>
        <el-row :gutter="14" style="margin-left: 3px;">
          <el-col :span="6" >
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px;">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon1.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>

          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px;">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon2.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>

          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon3.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>

          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon4.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>
        </el-row>

        <el-row :gutter="14" style="margin-left: 3px">
          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon5.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>
          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon6.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>
          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon7.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>
          <el-col :span="6">
            <el-link href="" :underline="false">
              <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 330px;height: 140px">
                <div class="bottom clearfix" style="padding: 2px;">
                  <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                </div>
                <div style="margin-top: 10px;margin-left: 3px">
                  <img src="../assets/img/tcicon8.png" style="width: 25%;">
                  <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                  <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                </div>
              </el-card>
            </el-link>
          </el-col>
        </el-row>
      </div>

      <!--##############################################################################################################-->
      <!--正在直播-->
      <div style="margin-top: 50px">
        <div style="font-family: 微软雅黑;font-size: 20pt;margin-left: 10px;">
          正在直播
        </div>
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1350px;margin-left: 8px;">
          <el-tab-pane label="语文" name="1">
            <el-row :gutter="10" style="margin-top: 20px;">
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link @click="centerDialogVisible = true" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px;">
                    <img src="../assets/img/coursepic/chinese1.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/7D625AB4-A9E0-47A0-BDA7-1FD8FD85B7BC" :underline="false" style="font-size: 15px">高三-鸿门宴</el-link>
                    </div>
                    <div class="bottom clearfix" style="padding: 2px;">
                      <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                    </div>
                  </el-card>
                </el-link>
                <el-dialog
                    title="请先登录"
                    :visible.sync="centerDialogVisible"
                    width="30%"
                    center
                    :before-close="handleClose">
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="centerDialogVisible = false">取 消</el-button>
                    <el-button type="primary" @click="login">确 定</el-button>
                  </span>
                </el-dialog>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese2.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false" style="font-size: 15px">《论语》的智慧</el-link>
                    </div>
                    <div class="bottom clearfix" style="padding: 2px;">
                      <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese3.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">一年读诗，一声爱诗</el-link>
                    </div>
                    <div class="bottom clearfix" style="padding: 2px;">
                      <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese4.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">读书的快乐，从四大名著谈起</el-link>
                    </div>
                    <div class="bottom clearfix" style="padding: 2px;">
                      <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 270px;height: 255px;">
                <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese5.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false" style="font-size: 15px">抗美援朝精神</el-link>
                    </div>
                    <div class="bottom clearfix" style="padding: 2px;">
                      <time class="time" style="  font-size: 13px;color: #999;">{{ currentDate }}</time>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10">
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://open.163.com/newview/movie/courseintro?newurl=%2Fspecial%2Fopencourse%2Fform.html" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px;">
                    <img src="../assets/img/coursepic/chinese6.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/courseintro?newurl=%2Fspecial%2Fopencourse%2Fform.html" :underline="false" style="font-size: 15px">文学与形式</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese7.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false" style="font-size: 15px">《论语》的智慧</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese8.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">一年读诗，一声爱诗</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese9.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">读书的快乐，从四大名著谈起</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 270px;height: 255px;">
                <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese10.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false" style="font-size: 15px">抗美援朝精神</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10">
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://open.163.com/newview/movie/courseintro?newurl=%2Fspecial%2Fopencourse%2Fform.html" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px;">
                    <img src="../assets/img/coursepic/chinese11.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/courseintro?newurl=%2Fspecial%2Fopencourse%2Fform.html" :underline="false" style="font-size: 15px">文学与形式</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese12.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=CEVBB19BM&mid=TEVBB19IS" :underline="false" style="font-size: 15px">《论语》的智慧</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese3.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">一年读诗，一声爱诗</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px;">
                <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese4.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.zybang.com/official/pages/opencourses/mingjiajiangtang" :underline="false" style="font-size: 15px">读书的快乐，从四大名著谈起</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 270px;height: 255px;">
                <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chinese5.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.xuetangx.com/course/elnu03051003111/5949157?channel=search_result" :underline="false" style="font-size: 15px">抗美援朝精神</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="数学" name="2">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false" style="font-size: 15px">一年级加、减法混合运算</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false" style="font-size: 15px">六年级分数的引入</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false" style="font-size: 15px">中考考点-点与圆的位置关系</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false" style="font-size: 15px">奥数九年级9-函数的基本概念与性质</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/math5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false" style="font-size: 15px">高三拓展理科-三角比的和差化积</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false" style="font-size: 15px">一年级加、减法混合运算</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false" style="font-size: 15px">六年级分数的引入</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false" style="font-size: 15px">中考考点-点与圆的位置关系</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false" style="font-size: 15px">奥数九年级9-函数的基本概念与性质</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/math5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false" style="font-size: 15px">高三拓展理科-三角比的和差化积</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/92613CC0-91BA-41E0-8FDB-BC4AF71CA8AA" :underline="false" style="font-size: 15px">一年级加、减法混合运算</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/3CBCE7FF-12F5-47D9-9B57-89DA3546E105" :underline="false" style="font-size: 15px">六年级分数的引入</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/ED100DA3-5D3C-4117-B320-CCA99A65BC5D" :underline="false" style="font-size: 15px">中考考点-点与圆的位置关系</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/math4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/8C2298E5-61C7-4ADA-8220-664B3931BEB8" :underline="false" style="font-size: 15px">奥数九年级9-函数的基本概念与性质</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/math5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/10099CE0-4988-4939-84A1-46CF821602BF" :underline="false" style="font-size: 15px">高三拓展理科-三角比的和差化积</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="英语" name="3">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English1.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">小学1-6年级学科英语</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English2.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">【看美剧学英语】摩登家庭</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400288/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English3.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400288/intro" :underline="false" style="font-size: 15px">少儿英语国际音标</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400241/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English4.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400241/intro" :underline="false" style="font-size: 15px">中考英语写作高效提分</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="https://class.hujiang.com/19401383/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/English5.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19401383/intro" :underline="false" style="font-size: 15px">星火单词-速记3500词</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English6.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">小学1-6年级学科英语</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English7.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">【看美剧学英语】摩登家庭</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400288/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English8.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400288/intro" :underline="false" style="font-size: 15px">少儿英语国际音标</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400241/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English9.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400241/intro" :underline="false" style="font-size: 15px">可数与不可数名词的常用修饰词</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="https://class.hujiang.com/19401383/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/English10.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19401383/intro" :underline="false" style="font-size: 15px">主动语态与被动语态的转换</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English11.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">新概念英语连读</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English12.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://open.163.com/newview/movie/free?pid=NFSG52T6J&mid=OFSG57GC4#share-mob" :underline="false" style="font-size: 15px">新概念英语1、2、3册连读-听说升级版</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400288/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English13.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400288/intro" :underline="false" style="font-size: 15px">少儿英语国际音标</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://class.hujiang.com/19400241/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/English14.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19400241/intro" :underline="false" style="font-size: 15px">“看漫画”速拓英文10000词</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="https://class.hujiang.com/19401383/intro" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/English15.jpg" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://class.hujiang.com/19401383/intro" :underline="false" style="font-size: 15px">如何像美国人一样流利说英语</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="物理" name="4">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/BC5EC88A-9642-45CE-AA2A-2235D359F43B" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/physic1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/BC5EC88A-9642-45CE-AA2A-2235D359F43B" :underline="false" style="font-size: 15px">高一重力做功与重力势能的关系</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/844C4A24-1E68-479D-B0E3-47BDEDB0C59F" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/physic2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/844C4A24-1E68-479D-B0E3-47BDEDB0C59F" :underline="false" style="font-size: 15px">高三拓展电场的叠加 静电平衡</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/55DA07E5-D4F8-4B4A-B5CF-14BD320371B2" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/physic3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/55DA07E5-D4F8-4B4A-B5CF-14BD320371B2" :underline="false" style="font-size: 15px">高考考点-光的衍射</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/D170750C-CF3C-4619-817E-866AD6C9BB7E" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/physic4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/D170750C-CF3C-4619-817E-866AD6C9BB7E" :underline="false" style="font-size: 15px">八年级光的折射与色散</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/C32A466C-3C6D-404B-87C0-4A13E39525D5" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/physic5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/C32A466C-3C6D-404B-87C0-4A13E39525D5" :underline="false" style="font-size: 15px">高考考点-动能定理1</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="化学" name="5">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/FA2E2EA5-96EE-4B80-B5F6-83B08A730F89" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height:250px">
                    <img src="../assets/img/coursepic/chem1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/FA2E2EA5-96EE-4B80-B5F6-83B08A730F89" :underline="false" style="font-size: 15px">高考考点-氧化还原反应4-方程式的配平</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/E860CF71-B4F5-47F0-855B-CA6164339136" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chem2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/E860CF71-B4F5-47F0-855B-CA6164339136" :underline="false" style="font-size: 15px">高考考点-烃6-各类烃的反应类型及实例1</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/A9FC6EB7-48C0-43B2-86F8-C4EF5F0A1DC2" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chem3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/A9FC6EB7-48C0-43B2-86F8-C4EF5F0A1DC2" :underline="false" style="font-size: 15px">高考考点-化学反应与能量的变化2-热化学反应的考题</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/1C8EF64F-327F-4B9C-AA65-EE85D83408DD" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/chem4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/1C8EF64F-327F-4B9C-AA65-EE85D83408DD" :underline="false" style="font-size: 15px">高考考点-铁、铜及其重要化合物7</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/6E8335EB-ED90-40FF-B2B3-7BE7B60DBF99" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/chem5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/6E8335EB-ED90-40FF-B2B3-7BE7B60DBF99" :underline="false" style="font-size: 15px">高考考点-离子反应1-电解质和非电解质</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="生物" name="6">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/927A3B6D-AB23-4E90-8FA2-5EEAE7782D38" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height:250px">
                    <img src="../assets/img/coursepic/bio1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/927A3B6D-AB23-4E90-8FA2-5EEAE7782D38" :underline="false" style="font-size: 15px">初中第二册微生物1-庞大的微生物家族</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/A13F90B5-3BD3-4FE9-A959-77C01EF4E181" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/bio2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/A13F90B5-3BD3-4FE9-A959-77C01EF4E181" :underline="false" style="font-size: 15px">高考考点-生态环境的保护</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/90388430-D881-43CE-9F47-5A2538F8B181" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/bio3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/90388430-D881-43CE-9F47-5A2538F8B181" :underline="false" style="font-size: 15px">高中第一册生物体内的化学反应2</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/9541629D-BE72-462A-9290-C59E6726562E" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/bio4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/9541629D-BE72-462A-9290-C59E6726562E" :underline="false" style="font-size: 15px">高中第三册生物的进化</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/17899D2F-8C85-43FF-A1D4-F23AA359411B" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/bio5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/17899D2F-8C85-43FF-A1D4-F23AA359411B" :underline="false" style="font-size: 15px">高中第二册减数分裂1</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>

          <el-tab-pane label="地理" name="7">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/AEB69122-4E40-48DB-80B3-08BE0DDEB0E6" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/geo1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/AEB69122-4E40-48DB-80B3-08BE0DDEB0E6" :underline="false" style="font-size: 15px">八年级水资源</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/048F7932-7199-411A-9469-C33FDE11A3BB" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height:250px">
                    <img src="../assets/img/coursepic/geo2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/048F7932-7199-411A-9469-C33FDE11A3BB" :underline="false" style="font-size: 15px">高中必修三区域农业发展-以我国东北地区为例3</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/28558071-F57E-4755-95ED-E64879CDDB8F" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/geo3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/28558071-F57E-4755-95ED-E64879CDDB8F" :underline="false" style="font-size: 15px">七年级人口与人种</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/93BCDC63-79E5-48CD-BCD2-22423B1CC084" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/geo4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/93BCDC63-79E5-48CD-BCD2-22423B1CC084" :underline="false" style="font-size: 15px">七年级大洲和大洋</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/AB6AC9B9-1D82-43C2-AD63-55C5959749CE" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/geo5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/AB6AC9B9-1D82-43C2-AD63-55C5959749CE" :underline="false" style="font-size: 15px">高中必修一河流地貌的发育</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="政治" name="8">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/pol1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="" :underline="false" style="font-size: 15px">七年级把握学习新节奏</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/pol2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="" :underline="false" style="font-size: 15px">七年级珍惜新起点</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/pol3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="" :underline="false" style="font-size: 15px">八年级老师伴我成长</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/pol4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="" :underline="false" style="font-size: 15px">八年级同侪携手共进</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/pol5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="" :underline="false" style="font-size: 15px">九年级了解基本国策与发展战略</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="历史" name="9">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/A2C155BD-7957-4FAA-BFB1-006F84BD8D94" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/his1.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/A2C155BD-7957-4FAA-BFB1-006F84BD8D94" :underline="false" style="font-size: 15px">高中选修二中国资产阶级的民主思想</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/C79CAE25-0694-402F-B40C-66FC768E6440" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/his2.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/C79CAE25-0694-402F-B40C-66FC768E6440" :underline="false" style="font-size: 15px">七年级明清经济的发展与“闭关锁国”</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/E1B177A6-8B65-4145-B228-766CAC7B4404" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/his3.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/E1B177A6-8B65-4145-B228-766CAC7B4404" :underline="false" style="font-size: 15px">七年级祖国境内的远古居民</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/71E9473B-EB8B-467A-8EC8-553B4EE61E83" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/his4.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/71E9473B-EB8B-467A-8EC8-553B4EE61E83" :underline="false" style="font-size: 15px">八年级中国人民站起来了</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="http://kuxuexi.com/video/detail/324FEF1D-EA68-47A2-8A79-26C6C5F0CEF3" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/his5.png" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="http://kuxuexi.com/video/detail/324FEF1D-EA68-47A2-8A79-26C6C5F0CEF3" :underline="false" style="font-size: 15px">高中选修三第一次世界大战的爆发2-大战导火索：萨拉热窝事件</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>
          <el-tab-pane label="计算机" name="10">
            <el-row :gutter="10" style="margin-top: 20px">
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://kaoyan.icourse163.org/course/terms/1464659442.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1463813161" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/comp1.webp" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://kaoyan.icourse163.org/course/terms/1464659442.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1463813161" :underline="false" style="font-size: 15px">计算机网络不挂科-4小时学完计算机网络</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://kaoyan.icourse163.org/course/terms/1464402452.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1463575164" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/comp2.webp" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://kaoyan.icourse163.org/course/terms/1464402452.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1463575164" :underline="false" style="font-size: 15px">数据结构与算法不挂科-5小时学完数据结构与算法</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://www.icourse163.org/course/ZJU-200001" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/comp3.webp" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.icourse163.org/course/ZJU-200001" :underline="false" style="font-size: 15px">C语言程序设计进阶</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 271px;height: 255px">
                <el-link href="https://www.icourse163.org/course/BIT-1205834821" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 260px;height: 250px">
                    <img src="../assets/img/coursepic/comp4.webp" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://www.icourse163.org/course/BIT-1205834821" :underline="false" style="font-size: 15px">大数据基础与应用</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col :span="5" style="width: 265px;height: 255px">
                <el-link href="https://kaoyan.icourse163.org/course/terms/1463201445.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1003296003" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="width: 255px;height: 250px">
                    <img src="../assets/img/coursepic/comp5.webp" style="width: 100%;display: block;">
                    <div style="padding: 10px;">
                      <el-link href="https://kaoyan.icourse163.org/course/terms/1463201445.htm?outVendor=zw_mooc_pcpdyzdyfltj_&courseId=1003296003" :underline="false" style="font-size: 15px">C语言不挂科-4小时学完C语言</el-link>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </el-tab-pane>
        </el-tabs>
      </div>

      <!--#################################################################################-->
      <!--分页栏-->
      <div class="block">
        <el-pagination
            background
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page.sync="currentPage"
            :page-size="100"
            layout="prev, pager, next, jumper"
            :total="1000" style="margin-left: 400px;margin-top: 50px;margin-right: 450px;">
        </el-pagination>
      </div>

    </el-main>


    <!--####################################################################################################################-->
    <!-- 底部  -->
    <el-footer style="background:	#272727; height: 300px; color: white">
      <div style="position: absolute">
        <img src="../assets/img/logo06.png" style="width: 220px;height: 70px;margin-top: 20px">
        <p style="font-size: 15px;color: #999;">由高教社联手网易推出，让每一个有提升愿望的用户能够学到免费的中小学课程，并获得认证</p>
      </div>
      <el-row class="foot-row" justify="space-between" style="margin-left: 750px; margin-top: 20px;margin-right: 40px;width: 600px">
        <el-col :span="20" style="font-size: 20px">
          <a>关于我们</a>
          <a style="margin-left: 300px">关注我们</a>
          <div style="margin-left: 365px;margin-top: 15px;position: absolute">
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weiboicon.jpg" width="55px" height="50px">
            </el-link>
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weixinicon.jpg" width="55px" height="50px" style="margin-left: 4px">
            </el-link>
          </div>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;">
        <el-col :span="10">
          <el-link href="" >关于我们</el-link>
          <el-link href="" style="margin-left: 25px">学校云</el-link>
          <el-link href="" style="margin-left: 28px">合作专区</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="" >联系我们</el-link>
          <el-link href="" style="margin-left: 20px">隐私政策</el-link>
          <el-link href="" style="margin-left: 20px">用户协议</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="">常见问题</el-link>
          <el-link href="" style="margin-left: 20px">法律条款</el-link>
          <el-link href="" style="margin-left: 20px">在线反馈</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;margin-bottom: 20px" >
        <el-col :span="10">
          <el-link href="">意见反馈</el-link>
          <el-link href="" style="margin-left: 20px">版权声明</el-link>
          <el-link href="" style="margin-left: 20px">网上有害信息举报</el-link>
        </el-col>
      </el-row>
      <div>
        <p style="font-size: 13px;color: #999;text-align: center">网上有害信息举报：网站 https://www.12377.cn 电话 010-58581010 邮箱 youdao_jubao@rd.netease.com</p>
        <el-link href="https://www.beianx.cn/info/16CD7AFD-FCBE-4361-859A-C6031989E89A.html" style="margin-left: 460px">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602000207">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="https://beian.tianyancha.com/ic5ea124352063">粤B2-20090191-26</el-link>
        <p style="font-size: 13px;color: #999;text-align: center">Copyright © 2021</p>
      </div>
    </el-footer>
  </el-container>

</template>

<script>
//引入video样式
// import 'video.js/dist/video-js.css'
// import 'vue-video-player/src/custom-theme.css'
// //引入hls.js
// import 'videojs-contrib-hls.js/src/videojs.hlsjs'

export default {
  name: "LiveCommunity",
  data() {
    return {
      user: JSON.parse(window.sessionStorage.getItem("user")),
      input: '',
      activeIndex: '1',
      currentPage: 1,
      // currentDate: new Date(),
      currentDate: "", // 当前日期
      centerDialogVisible: false
      // playerOptions: {
      //   playbackRates: [0.7, 1.0, 1.5, 2.0], //播放速度
      //   autoplay: false, //如果true,浏览器准备好时开始回放。
      //   controls: true, //控制条
      //   preload: 'auto', //视频预加载
      //   muted: false, //默认情况下将会消除任何音频。
      //   loop: false, //导致视频一结束就重新开始。
      //   language: 'zh-CN',
      //   aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
      //   fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
      //   sources: [{
      //     type: 'video/mp4',
      //     src: '//vjs.zencdn.net/(…)oceans.mp4'//你所放置的视频的地址，最好是放在服务器上
      //   }],
      //   poster: "//vjs.zencdn.net/(…)oceans.png", //你的封面地址（覆盖在视频上面的图片）
      //   width: document.documentElement.clientWidth,
      //   notSupportedMessage: '此视频暂无法播放，请稍后再试' //允许覆盖Video.js无法播放媒体源时显示的默认信息。
      // }
    };
  },
  mounted() {
    window.addEventListener("scroll",this.watchScroll);
    this.currentTime();
  },
  // 销毁定时器
  beforeDestroy() {
    if (this.formatDate) {
      clearInterval(this.formatDate); // 在Vue实例销毁前，清除时间定时器
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
    },
    currentTime() {
      setInterval(this.formatDate, 500);
    },
    formatDate() {
      let date = new Date();
      let year = date.getFullYear(); // 年
      let month = date.getMonth() + 1; // 月
      let day = date.getDate(); // 日
      let week = date.getDay(); // 星期
      let weekArr = [ "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" ];
      let hour = date.getHours(); // 时
      hour = hour < 10 ? "0" + hour : hour; // 如果只有一位，则前面补零
      let minute = date.getMinutes(); // 分
      minute = minute < 10 ? "0" + minute : minute; // 如果只有一位，则前面补零
      // let second = date.getSeconds(); // 秒
      // second = second < 10 ? "0" + second : second; // 如果只有一位，则前面补零
      // this.currentDate = `${year}/${month}/${day} ${hour}:${minute}:${second} ${weekArr[week]}`;
      this.currentDate = `${year}/${month}/${day} ${hour}:${minute} ${weekArr[week]}`;
    },
    watchScroll() {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollTop > 49) {
        this.navBarFixed = true
      } else {
        this.navBarFixed = false
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    init () {
      this.$router.replace("/init")
    },
    login () {
      this.$router.replace("/login")
    },
    course () {
      this.$router.replace("/course")
    },
    teacherteam () {
      this.$router.replace("/teacherteam")
    },
    livecommunity() {
      this.$router.replace("/livecommunity")
    },
    information() {
      this.$router.replace("/information")
    },
    aboutus () {
      this.$router.replace("/aboutus")
    },
  }
}
</script>

<style scoped>
.foot-row {
  margin-top: 10px;
}

/*顶部固定*/
.navBarWrap {
  position:fixed;
  top:0;
  z-index:999;
}
</style>