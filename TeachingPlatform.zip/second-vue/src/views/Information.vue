<template>
<!--留言板-->
  <el-container style="height: 100%; margin: fill;">
<!--####################################################################################################################-->
    <!--头部导航栏-->
    <el-header style="height: 80px;">
      <div style="width:230px; position: absolute;">
        <a href="" title="名师有享">
          <img src="../assets/img/logo05.png" width="220px" height="70px">
        </a>
      </div>
      <div style="position: absolute;margin-left: 270px;margin-top: 0px;">
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px;">
          <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
          <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px;">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item divided>
                <strong>小学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>编程</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>中学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>高中课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <el-link @click="teacherteam" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
          <el-link @click="livecommunity" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
          <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
          <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
          <el-input
              style="width: 230px; height: 100px; margin-left: 130px; margin-top: 10px"
              placeholder="请输入内容"
              v-model="input">
            <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
            <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
          </el-input>
          <b-nav-item v-if="user != null">
            <el-link @click="person" :underline="false" style="margin-left: 40px;font-size: 18px">个人中心</el-link>
          </b-nav-item>
          <b-nav-item v-if="user == null">
            <el-link target="_blank" @click="login" style="margin-left: 30px">登录</el-link>
            <a style="margin-left: 5px"> | </a>
            <el-link target="_blank" @click="register" style="margin-left: 5px">注册</el-link>
          </b-nav-item>
        </el-tabs>
      </div>
    </el-header>


<!--####################################################################################################################-->
    <!--内容-->
    <el-main :style="note" style="background: #F0F0F0;">

      <el-tabs v-model="activeIndex" :tab-position="tabPosition" style="height: 500px;" @tab-click="handleClickTab">
        <el-tab-pane label="留言信息" name="1">
          <div>
            <el-table
                :data="infoData"
                border
                style="width: 100%">
              <el-table-column
                  prop="name"
                  label="昵称"
                  width="120">
              </el-table-column>
              <el-table-column
                  prop="title"
                  label="标题"
                  width="120">
              </el-table-column>
              <el-table-column
                  prop="type"
                  label="留言类别"
                  width="120">
              </el-table-column>
              <el-table-column
                  prop="interpretion"
                  label="详细说明">
              </el-table-column>
            </el-table>
          </div>
        </el-tab-pane>

        <el-tab-pane label="写留言" name="2">
        <el-button @click="addInfo" style="background-color: rgba(255,255,255,0);">写留言</el-button>
          <div>
            <span style="font-size: 30px;font-family: 宋体;margin-left: 10px;">在线留言</span>
          </div>

          <el-form :model="informations" :rules="rules" ref="informations" label-width="100px" class="demo-ruleForm" style="margin-top: 5px">
            <el-form-item label="昵称" prop="name">
              <el-input v-model="informations.name" style="width: 300px"></el-input>
            </el-form-item>
            <el-form-item label="标题" prop="title">
              <el-input v-model="informations.title" style="width: 500px"></el-input>
            </el-form-item>
            <el-form-item label="留言类别" prop="type">
              <el-select v-model="informations.type" placeholder="请选择留言类别">
                <el-option label="意见反馈" value="意见反馈"></el-option>
                <el-option label="网站建议" value="网站建议"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="详细说明" prop="interpretion">
              <el-input type="textarea"
                        :autosize="{ minRows: 8, maxRows: 8}"
                        v-model="informations.interpretion"
                        placeholder="请详细说明"
                        style="width: 1000px;height: 180px;"
                        clearable>
              </el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm">提交</el-button>
              <el-button @click="dialogFormVisible = false">取消</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>

      </el-tabs>

    </el-main>

<!--####################################################################################################################-->
    <!-- 底部  -->
    <el-footer style="background: #272727; height: 300px; color: white">
      <div style="position: absolute">
        <img src="../assets/img/logo06.png" style="width: 220px;height: 70px;margin-top: 20px">
        <p style="font-size: 15px;color: #999;">由高教社联手网易推出，让每一个有提升愿望的用户能够学到免费的中小学课程，并获得认证</p>
      </div>
      <el-row class="foot-row" justify="space-between" style="margin-left: 750px; margin-top: 20px;margin-right: 40px;width: 600px">
        <el-col :span="20" style="font-size: 20px">
          <a>关于我们</a>
          <a style="margin-left: 300px">关注我们</a>
          <div style="margin-left: 365px;margin-top: 15px;position: absolute">
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weiboicon.jpg" width="55px" height="50px">
            </el-link>
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weixinicon.jpg" width="55px" height="50px" style="margin-left: 4px">
            </el-link>
          </div>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;">
        <el-col :span="10">
          <el-link href="" >关于我们</el-link>
          <el-link href="" style="margin-left: 25px">学校云</el-link>
          <el-link href="" style="margin-left: 28px">合作专区</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="" >联系我们</el-link>
          <el-link href="" style="margin-left: 20px">隐私政策</el-link>
          <el-link href="" style="margin-left: 20px">用户协议</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="">常见问题</el-link>
          <el-link href="" style="margin-left: 20px">法律条款</el-link>
          <el-link href="" style="margin-left: 20px">在线反馈</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;margin-bottom: 20px" >
        <el-col :span="10">
          <el-link href="">意见反馈</el-link>
          <el-link href="" style="margin-left: 20px">版权声明</el-link>
          <el-link href="" style="margin-left: 20px">网上有害信息举报</el-link>
        </el-col>
      </el-row>
      <div>
        <p style="font-size: 13px;color: #999;text-align: center">网上有害信息举报：网站 https://www.12377.cn 电话 010-58581010 邮箱 youdao_jubao@rd.netease.com</p>
        <el-link href="https://www.beianx.cn/info/16CD7AFD-FCBE-4361-859A-C6031989E89A.html" style="margin-left: 460px">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602000207">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="https://beian.tianyancha.com/ic5ea124352063">粤B2-20090191-26</el-link>
        <p style="font-size: 13px;color: #999;text-align: center">Copyright © 2021</p>
      </div>
    </el-footer>

  </el-container>
</template>

<script>
export default {
  name: "Information",
  data() {
    return {
      input: '',
      activeIndex: '1',
      tabPosition:'left',
      dialogFormVisible: false,
      infoData:[],
      user: JSON.parse(window.sessionStorage.getItem("user")),
      note: {
        backgroundImage: "url(" + require("../assets/img/background/information_bg1.jpg") + ")",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        height: "596px"
      },
      informations: {
        name: '',
        title: '',
        type: '',
        interpretion: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入昵称', trigger: 'blur' }
        ],
        title: [
          { required: true, message: '请输入留言标题', trigger: 'blur' },
          { min: 2, max: 50, message: '长度不要超过50个字', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '请选择留言类别', trigger: 'change' }
        ],
        interpretion: [
          { required: true, message: '请填写详细说明', trigger: 'blur' }
        ]
      }
    };
  },
  mounted() {
    window.addEventListener("scroll",this.watchScroll);
  },
  created() {
    this.findAllInfos();
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    submitForm() {
      if (this.dialogStatus === 'addInfo'){
        this.submit();
      }
    },
    submit () {
          this.$axios.post("/information/addInfo",this.informations).then( (resp)=>{
            if (resp) {
              this.dialogFormVisible = false;
              this.information = {}
              this.$message.success("添加成功！");
              this.findAllInfos();
            }
          }).catch((error)=>{
            this.$message({
              message: '添加数据失败，原因是'+error.data.message,
              type: 'error'
            })
          })
      },
    addInfo () {
      this.dialogFormVisible = true;
      this.dialogStatus = "addInfo";
    },
    findAllInfos () {
      this.$axios.get("information/findAllInfos").then ( (resp)=>{
        this.infoData = resp.data
      }).catch( (error)=>{
        this.$message({
          type: 'error',
          message: "查询失败，原因是"+error.data.message
        });
      })
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
    },
    handleClickTab(tab, event) {
      console.log(tab, event);
      if(tab.name == '2'){
        // 触发‘配置管理’事件
        console.log('我是配置管理');
      }else{
        // 触发‘用户管理’事件
        console.log('我是用户管理');
      }
    },
    watchScroll() {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollTop > 49) {
        this.navBarFixed = true
      } else {
        this.navBarFixed = false
      }
    },
    init () {
      this.$router.replace("/init")
    },
    login () {
      this.$router.replace("/login")
    },
    course () {
      this.$router.replace("/course")
    },
    person () {
      this.$router.replace("/person")
    },
    teacherteam () {
      this.$router.replace("/teacherteam")
    },
    livecommunity() {
      this.$router.replace("/livecommunity")
    },
    information() {
      this.$router.replace("/information")
    },
    aboutus () {
      this.$router.replace("/aboutus")
    },

  }
}
</script>

<style scoped>
.foot-row {
  margin-top: 10px;
}

/*顶部固定*/
.navBarWrap {
  position:fixed;
  top:0;
  z-index:999;
}

</style>