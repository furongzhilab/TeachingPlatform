<template>
<!--教师团队-->
  <el-container style="height: 100%; margin: fill;">
    <!--####################################################################################################################-->
    <!--头部导航栏-->
    <el-header style="height: 80px;">
      <div style="width:230px; position: absolute;">
        <a href="" title="名师有享">
          <img src="../assets/img/logo05.png" width="220px" height="70px">
        </a>
      </div>
      <div style="position: absolute;margin-left: 270px;margin-top: 0px;">
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px;">
          <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
          <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px;">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item divided>
                <strong>小学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>编程</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>中学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>高中课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <el-link @click="teacherteam" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
          <el-link @click="livecommunity" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
          <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
          <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
          <el-input
              style="width: 230px; height: 100px; margin-left: 130px; margin-top: 10px"
              placeholder="请输入内容"
              v-model="input">
            <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
            <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
          </el-input>
          <el-link target="_blank" @click="login" style="margin-left: 30px">登录</el-link>
          <a style="margin-left: 5px"> | </a>
          <el-link target="_blank" style="margin-left: 5px">注册</el-link>
        </el-tabs>
      </div>
    </el-header>


<!--####################################################################################################################-->
    <!--内容-->
<!--    <img src="../assets/img/background/aboutus_bg1.png">-->
    <img src="../assets/img/background/bg0.jpg">
    <img src="../assets/img/background/bg4.jpg">
    <img src="../assets/img/background/bg1.jpg">
    <img src="../assets/img/background/bg2.jpg">
    <img src="../assets/img/background/bg3.jpg">
    <img src="../assets/img/background/bg5.jpg">

<!--    <el-main style="background: #F0F0F0;">-->
<!--      内容-->
<!--    </el-main>-->

    <!--####################################################################################################################-->
    <!-- 底部  -->
    <el-footer style="background:	#272727; height: 300px; color: white">
      <div style="position: absolute">
        <img src="../assets/img/logo06.png" style="width: 220px;height: 70px;margin-top: 20px">
        <p style="font-size: 15px;color: #999;">由高教社联手网易推出，让每一个有提升愿望的用户能够学到免费的中小学课程，并获得认证</p>
      </div>
      <el-row class="foot-row" justify="space-between" style="margin-left: 750px; margin-top: 20px;margin-right: 40px;width: 600px">
        <el-col :span="20" style="font-size: 20px">
          <a>关于我们</a>
          <a style="margin-left: 300px">关注我们</a>
          <div style="margin-left: 365px;margin-top: 15px;position: absolute">
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weiboicon.jpg" width="55px" height="50px">
            </el-link>
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weixinicon.jpg" width="55px" height="50px" style="margin-left: 4px">
            </el-link>
          </div>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;">
        <el-col :span="10">
          <el-link @click="aboutus" >关于我们</el-link>
          <el-link href="" style="margin-left: 25px">学校云</el-link>
          <el-link href="" style="margin-left: 28px">合作专区</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link @click="aboutus" >联系我们</el-link>
          <el-link @click="aboutus" style="margin-left: 20px">隐私政策</el-link>
          <el-link @click="aboutus" style="margin-left: 20px">用户协议</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="">常见问题</el-link>
          <el-link @click="aboutus" style="margin-left: 20px">法律条款</el-link>
          <el-link @click="information" style="margin-left: 20px">在线反馈</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;margin-bottom: 20px" >
        <el-col :span="10">
          <el-link @click="information">意见反馈</el-link>
          <el-link @click="aboutus" style="margin-left: 20px">版权声明</el-link>
          <el-link href="https://www.12377.cn" style="margin-left: 20px">网上有害信息举报</el-link>
        </el-col>
      </el-row>
      <div>
        <p style="font-size: 13px;color: #999;text-align: center">网上有害信息举报：网站 https://www.12377.cn 电话 010-58581010 邮箱 youdao_jubao@rd.netease.com</p>
        <el-link href="https://www.beianx.cn/info/16CD7AFD-FCBE-4361-859A-C6031989E89A.html" style="margin-left: 460px">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602000207">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="https://beian.tianyancha.com/ic5ea124352063">粤B2-20090191-26</el-link>
        <p style="font-size: 13px;color: #999;text-align: center">Copyright © 2021</p>
      </div>
    </el-footer>
  </el-container>

</template>

<script>
export default {
  name: "Teacherteam",
  data() {
    return {
      input: '',
      activeIndex: '1',
    };
  },
  mounted() {
    window.addEventListener("scroll",this.watchScroll);
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    watchScroll() {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollTop > 49) {
        this.navBarFixed = true
      } else {
        this.navBarFixed = false
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    init () {
      this.$router.replace("/init")
    },
    login () {
      this.$router.replace("/login")
    },
    course () {
      this.$router.replace("/course")
    },
    teacherteam () {
      this.$router.replace("/teacherteam")
    },
    livecommunity() {
      this.$router.replace("/livecommunity")
    },
    information() {
      this.$router.replace("/information")
    },
    aboutus () {
      this.$router.replace("/aboutus")
    },
  }
}
</script>

<style scoped>
.foot-row {
  margin-top: 10px;
}

/*顶部固定*/
.navBarWrap {
  position:fixed;
  top:0;
  z-index:999;
}
</style>