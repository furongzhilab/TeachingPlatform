<template>
  <div style="margin-top: 20px">
  <el-table
      :data="userData"
      border
      style="width: 100%">
    <el-table-column
        prop="name"
        label="中文名"
        width="120">
    </el-table-column>
    <el-table-column
        prop="username"
        label="登录名"
        width="120">
    </el-table-column>
    <el-table-column
        prop="phone"
        label="联系电话">
    </el-table-column>
    <el-table-column
        prop="telephone"
        label="座机">
    </el-table-column>
    <el-table-column
        prop="address"
        label="地址">
    </el-table-column>
    <el-table-column
        prop="registTime"
        label="注册时间">
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="scope">
        <el-button type="primary"
            size="mini"
            @click="showEditView(scope.row)">编辑</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-dialog :title="dialogTitle[dialogStatus]" :visible.sync="dialogFormVisible" center>
    <el-form :model="user" :rules="rules" ref="user">
      <el-form-item label="中文名" :label-width="formLabelWidth" prop="name">
        <el-input v-model="user.name" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="英文名" :label-width="formLabelWidth" prop="username">
        <el-input v-model="user.username"></el-input>
      </el-form-item>
      <el-form-item label="密码" :label-width="formLabelWidth" prop="password">
        <el-input type="password" v-model="user.password" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="手机" :label-width="formLabelWidth" prop="phone">
        <el-input v-model.number="user.phone" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="地址" :label-width="formLabelWidth" prop="address">
        <el-input v-model.number="user.address" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="座机" :label-width="formLabelWidth" prop="telephone">
        <el-input v-model="user.telephone" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="是否可用" :label-width="formLabelWidth" prop="enabled">
        <el-switch
            v-model="user.enabled"
            active-text="启用"
            inactive-text="禁用">
        </el-switch>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
    </div>
  </el-dialog>
  </div>
</template>

<script>
export default {
  name: "Personal",
  data () {
    return {
      userData:[],
      dialogTitle: {
        editUser: "编辑用户"
      },
      dialogStatus: "",
      dialogFormVisible: false,
      user:{
        enabled:false,
        telephone: '',
        registTime: ''
      },
      formLabelWidth: "120px",
      rules: {
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' }
        ],
        username: [
          { required: true, message: '请输入登录名', trigger: 'blur' }
        ]
      },
    }
  },
  created() {
    this.findAllUsers();
  },
  methods: {
    showEditView(row) {
      this.user = row;
      this.dialogFormVisible = true;
      this.dialogStatus = "editUser";
    },
    submit() {
      if (this.dialogStatus === "editUser") {
        this.editUser();
      }
    },
    editUser() {
      this.$refs.user.validate((valid) => {
        if (valid) {
          this.$axios.post("/personal/updateInfo", this.user).then((resp) => {
            if (resp) {
              this.dialogFormVisible = false;
              this.$message.success("修改成功");
              this.findAllUsers();
            }
          }).catch((error) => {
            this.$message({
              message: '修改数据失败，原因是' + error.data.message,
              type: 'error'
            })
          })
        } else {
          this.$message({
            message: '请输入所有字段',
            type: 'error'
          })
          return false;
        }
      });
    },
    findAllUsers() {
      this.$axios.get("personal/findSelfInfo").then((resp) => {
        this.userData = resp.data
      }).catch((error) => {
        this.$message({
          type: 'error',
          message: "查询失败，原因是" + error.data.message
        });
      })
    },
  }
}
</script>

<style scoped>

</style>