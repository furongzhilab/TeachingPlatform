<template>
  <el-container>
    <el-header class="headerlogin" style="height: 150px">
      <img class="redlogo" src="../assets/img/logo05.png" style="margin-left: 40px;width:280px;height: 100px"/>
      <div class="title" style="margin-left: 340px">中小学教辅平台</div>
    </el-header>
    <div class="background">
      <img src="../assets/img/background01.jpg" width="100%" height="110%" alt=""/>
    </div>
    <div class="login_bg">
      <el-form :model="loginForm"  :rules="rules" ref="userForm" class="login">  <!-- ":"代表绑定，model绑定数据 -->
        <el-form-item prop="username">
          <el-input type="text" v-model="loginForm.username" placeholder="请输入用户名" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="loginForm.password" autocomplete="off" placeholder="请输入密码" @keydown.enter.native="submit"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="text" style="width: 55%; margin-top: 10px" @click="register()">没有账号？现在注册</el-button>
          <el-button type="primary" style="width: 30%; margin-left: 30px" @click="submit()">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-container>
</template>

<script>
    import {postKeyValueRequest} from "../config/interceptor";

    export default {
        name: "Login",
        data () {
            return {
                rules: {
                    username: [{ required: true, message: '请输入用户名', trigger: 'blur' },],
                    password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
                },
                loginForm: {
                    // username: "admin",
                    // password: "123456"
                  username: "",
                  password: ""
                }
            }
        },
        methods: {
            submit() {
                this.$refs.userForm.validate((valid) => { //$refs获取所有带有ref属性的表单
                  this.bus.$emit('loading', true);
                    if (valid) {
                        postKeyValueRequest("/doLogin",this.loginForm).then( (res)=> {
                            if(res.data.obj !=null) {
                                window.sessionStorage.setItem("user",JSON.stringify(res.data.obj))
                                let path = this.$route.query.redirect;
                                this.$router.replace((path === '/'||path === undefined)?"/person":path)
                              this.bus.$emit('loading', false);
                            }
                        })
                    } else {
                      this.bus.$emit('loading', false);
                            this.$message({
                                message: '请输入所有字段',
                                type: 'error'
                            });
                            return false
                    }
                });
            },
          register() {
              this.$router.replace("/register")
          }
        }
    }
</script>

<style scoped>
    .background{
      width: 100%;
      height: 75%;
      margin: 110px auto;
      z-index: -1;
      position: absolute;
    }
    .title {
      font-size: 30px;
      font-family: 华文隶书;
      color: #000;
      margin: -20px 0px 0px 430px;
    }
    .login {
        width: 270px;
        border-radius: 15px;
        background-clip: padding-box;
        background-color: rgba(255,255,255,0.7);
        margin: 300px 50px 150px 880px;
        padding: 35px 35px 15px 35px;
        border: 1px solid #eaeaea;
        /*水平位置 垂直位置 阴影大小 阴影颜色*/
        box-shadow: 0 0 25px #cac6c6;
    }
    .login_bg{
      margin-left: 100px;
      z-index: 1;
      position: absolute;
    }
</style>
