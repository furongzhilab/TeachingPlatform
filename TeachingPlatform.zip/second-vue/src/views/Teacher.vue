<template>
<!--教师团队-->
  <div>
    <div style="margin-top:50px;">
      <el-input v-model="teacherName" placeholder="请输入教师姓名" style="width:80%" clearable></el-input>
      <el-button type="primary" style="margin-left: 10px;" @click="searchTeacherByName">搜索</el-button>
      <el-button type="primary" style="margin-left:10px;margin-bottom: 20px;" @click="showDialog">新增教师</el-button>
    </div>
    <div>
      <el-table
          @selection-change="handleSelectionChange"
          :data="teachers"
          border>
        <el-table-column
            type="selection"
            width="55">
        </el-table-column>
        <el-table-column
            prop="uid"
            label="id"
            align="center"
            width="60">
        </el-table-column>
        <el-table-column
            prop="id"
            label="工号"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="name"
            label="姓名"
            align="center"
            width="80">
        </el-table-column>
        <el-table-column
            prop="sex"
            label="性别"
            align="center"
            width="50">
        </el-table-column>
        <el-table-column
            prop="age"
            label="年龄"
            align="center"
            width="50">
        </el-table-column>
        <el-table-column
            prop="school"
            label="学校"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="education"
            label="学历"
            align="center"
            width="80">
        </el-table-column>
        <el-table-column
            prop="phone"
            label="联系电话"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="location"
            label="住址"
            align="center"
            width="180"
            :formatter="locationFormat">
        </el-table-column>
        <el-table-column
            prop="birth"
            label="生日"
            align="center"
            :formatter="dateformat"
            width="100">
        </el-table-column>
        <el-table-column
            prop="major"
            label="专业"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="e_mail"
            label="电子邮件"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="nation"
            label="民族"
            align="center"
            width="80">
        </el-table-column>
        <el-table-column
            prop="native_place"
            label="籍贯"
            align="center"
            width="100">
        </el-table-column>
        <el-table-column
            prop="technical_post"
            label="职称"
            align="center"
            width="100">
        </el-table-column>
        <el-table-column
            prop="english_level"
            label="英语水平"
            align="center"
            width="80">
        </el-table-column>
        <el-table-column
            prop="computer_level"
            label="计算机水平"
            align="center"
            width="100">
        </el-table-column>
        <el-table-column
            prop="hobby"
            label="爱好"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="motto"
            label="座右铭"
            align="center"
            width="180">
        </el-table-column>
        <el-table-column
            prop="working"
            label="是否在职">
          <template slot-scope="scope">
            <el-tag size="small" type="success" v-if="scope.row.working">在职教师</el-tag>
            <el-tag size="small" type="danger" v-else>兼职教师</el-tag>
          </template>
        </el-table-column>

        <el-table-column
            fixed="right"
            label="操作"
            width="100">
          align="left">
          <template slot-scope="scope">
            <el-button
                size="mini"
                @click="handleEdit(scope.row)">编辑</el-button>
            <el-button
                size="mini"
                type="danger"
                @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-button type="danger" size="mini" style="margin-top: 12px" :disabled="multipleSelection.length === 0" @click="deleteTeachers">批量删除</el-button>
    </div>
    <el-dialog :title="dialogTitle[dialogStatus]" :visible.sync="dialogFormVisible" center>
      <el-form :model="form" :rules="rules" ref="teacher" style="width: 100%">
        <el-form-item label="工号" :label-width="formLabelWidth" prop="id">
          <el-input v-model="form.id" maxlength="13" autocomplete="off" placeholder="请输入工号" clearable></el-input>
        </el-form-item>
        <el-form-item label="姓名" :label-width="formLabelWidth" prop="name">
          <el-input v-model="form.name" autocomplete="off" placeholder="请输入真实姓名" clearable></el-input>
        </el-form-item>
        <el-form-item label="性别" :label-width="formLabelWidth" prop="sex">
          <el-select v-model="form.sex" placeholder="请选择" style="width: 100%">
            <el-option
                v-for="item in options"
                :key="item.value"
                :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="年龄" :label-width="formLabelWidth" prop="age">
          <el-input v-model.number="form.age" maxlength="3" autocomplete="off" placeholder="请输入年龄"></el-input>
        </el-form-item>
        <el-form-item label="学校" :label-width="formLabelWidth" prop="school">
          <el-input v-model="form.school" autocomplete="off" placeholder="请输入毕业院校" clearable></el-input>
        </el-form-item>
        <el-form-item label="学历" :label-width="formLabelWidth" prop="education">
          <el-select v-model="form.education" placeholder="请选择" style="width: 100%">
            <el-option
                v-for="item in option_education"
                :key="item.value"
                :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="联系电话" :label-width="formLabelWidth" prop="phone">
          <el-input v-model.number="form.phone" maxlength="11" autocomplete="off" placeholder="请输入联系电话" clearable></el-input>
        </el-form-item>
        <el-form-item label="家庭住址" :label-width="formLabelWidth" prop="location">
          <el-cascader
                    v-model="form.locations"
                    placeholder="请选择家庭住址"
                    :options="option_location"
                    :props="{ expandTrigger: 'hover' }">
          </el-cascader>
        </el-form-item>
        <el-form-item label="生日" :label-width="formLabelWidth" prop="birth">
          <el-col :span="12">
            <el-date-picker
                style="width: 100%"
                v-model="form.birth"
                type="date"
                placeholder="选择日期"
                value-format="yyyy-MM-dd">
            </el-date-picker>
          </el-col>
          <el-col class="line" :span="2.5"></el-col>
        </el-form-item>
        <el-form-item label="专业" :label-width="formLabelWidth" prop="major">
          <el-input v-model="form.major" autocomplete="off" placeholder="请输入学习专业" clearable></el-input>
        </el-form-item>
        <el-form-item label="电子邮件" :label-width="formLabelWidth" prop="e_mail">
          <el-input v-model="form.e_mail" autocomplete="off" placeholder="请输入电子邮箱" clearable></el-input>
        </el-form-item>
        <el-form-item label="民族" :label-width="formLabelWidth" prop="nation">
          <el-input v-model="form.nation" autocomplete="off" placeholder="请输入民族"></el-input>
        </el-form-item>
        <el-form-item label="籍贯" :label-width="formLabelWidth" prop="native_place">
          <el-input v-model="form.native_place" autocomplete="off" placeholder="请输入籍贯"></el-input>
        </el-form-item>
        <el-form-item label="职称" :label-width="formLabelWidth" prop="technical_post">
          <el-select v-model="form.technical_post" placeholder="请选择" style="width: 100%">
            <el-option
                v-for="item in option_technical_post"
                :key="item.value"
                :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="英语水平" :label-width="formLabelWidth" prop="english_level">
          <el-select v-model="form.english_level" placeholder="请选择" style="width: 100%">
            <el-option
                v-for="item in option_english_level"
                :key="item.value"
                :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="计算机水平" :label-width="formLabelWidth" prop="computer_level">
          <el-select v-model="form.computer_level" placeholder="请选择" style="width: 100%">
            <el-option
                v-for="item in option_computer_level"
                :key="item.value"
                :value="item.label">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="爱好" :label-width="formLabelWidth" prop="hobby">
          <el-checkbox-group v-model="form.hobbys">
            <el-checkbox label="运动"></el-checkbox>
            <el-checkbox label="娱乐"></el-checkbox>
            <el-checkbox label="学习"></el-checkbox>
            <el-checkbox label="冒险"></el-checkbox>
            <el-checkbox label="智力"></el-checkbox>
            <el-checkbox label=“美食"></el-checkbox>
            <el-checkbox label="旅游"></el-checkbox>
            <el-checkbox label="乐器"></el-checkbox>
            <el-checkbox label="游戏"></el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="座右铭" :label-width="formLabelWidth" prop="motto">
          <div style="margin: 20px 0;"></div>
          <el-input
              type="textarea"
              placeholder="请输入内容"
              v-model="form.motto"
              maxlength="30"
              show-word-limit
              clearable
          >
          </el-input>
        </el-form-item>
        <el-form-item label="是否在职" :label-width="formLabelWidth" prop="working">
          <el-switch
              v-model="form.working"
              active-text="在职"
              inactive-text="兼职">
          </el-switch>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitTeacher">确 定</el-button>
      </div>
    </el-dialog>
    <el-upload
        style="margin-top:20px;"
        action="/upload"
        multiple
        :on-success="handleSuccess"
        :limit="3"
        :file-list="fileList">
      <el-button size="small" type="primary">点击上传</el-button>
    </el-upload>
  </div>
</template>

<script>
// @ is an alias to /src

import { regionData, CodeToText } from "element-china-area-data"

export default {
  name: 'Home',
  components: {
  },
  data () {
    var validateAge = (rule, value,callback) =>{
      if(value < 20 || value > 60) {
        callback(new Error('请输入[20,60]之间的数字'));
      } else {
        callback();
      }
    };
    return {
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      fileList: [],
      teacherName: '',
      multipleSelection:[],
      dialogTitle: {
        addTeacher: "新增教师",
        editTeacher: "编辑教师"
      },
      dialogStatus: "",
      rules: {
        id: [
          { required: true, message: '请输入工号', trigger: 'blur' },
          { min: 13, message: '请输入正确的工号'},
          //{ pattern: /^[a-z0-9A-Z]+$/, message: '工号不能包括中文'}
        ],
        name: [
          { required: true, message: '请输入姓名', trigger: 'blur' },
          { pattern: /^[\u0391-\uFFE5A-Za-z]+$/, message: '姓名必须是中文或英文'},
          //{ min:2, max:92, message: '长度在2到92个字符'}
        ],
        sex: [
          { required: true, message: '请选择性别', trigger: 'change' }
        ],
        age: [
          { required: true, message: '年龄不能为空',trigger: 'blur'},
          { type: 'number', message: '年龄必须为数字值'},
          //{ validator: validateAge, trigger: 'change'},
          { pattern: /^[0-9]+(.[0-9]{2})?$/, message: '请输入正确的数值'}
        ],
        school: [
          { required: true, message: '请输入学校', trigger: 'blur' },
          { pattern: /^[\u0391-\uFFE5A-Za-z]+$/, message: '学校必须是中文或英文'},
          { min:4, max:13, message: '长度在4到13个字符'}
        ],
        education: [
          { required: true, message: '请选择学历', trigger: 'change' }
        ],
        phone: [
          { required: true, message: '请输入联系电话', trigger: 'blur'},
          { type: 'number', message: '电话必须为数字值'},
          //{ pattern: /^(13[0-9]|14[0-9]|15[0-9]|16[6]|18[0-9]|19[6,9]|17[0-9])\d{8}$/i, message: '请输入正确的电话号码'}
        ],
        e_mail: [
          { pattern: /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/, message: '请输入有效的电子邮箱'}
        ],
        major: [
          { required: true, message: '请输入专业', trigger: 'blur' },
          { pattern: /^[\u0391-\uFFE5A-Za-z]+$/, message: '专业必须是中文或英文'},
          { min:2, max:10, message: '长度在2到10个字符'}
        ],
      },
      options: [{
        value: '1',
        label: '男'
      }, {
        value: '2',
        label: '女'
      }],
      option_education: [{
        value: '1',
        label: '本科',
      }, {
        value: '2',
        label: '硕士',
      }, {
        value: '3',
        label: '博士',
      }, {
        value: '4',
        label: '专科',
      }, {
        value: '5',
        label: '高中'
      }],
      option_technical_post: [{
        value: '1',
        label: '正高级教师',
      }, {
        value: '2',
        label: '高级教师',
      }, {
        value: '3',
        label: '一级教师',
      }, {
        value: '4',
        label: '二级教师',
      }, {
        value: '5',
        label: '三级教师'
      }],
      option_english_level: [{
        value: '1',
        label: 'CET6',
      }, {
        value: '2',
        label: 'CET4',
      }, {
        value: '3',
        label: 'TEM8',
      }, {
        value: '4',
        label: 'TEM4',
      }],
      option_computer_level: [{
        value: '1',
        label: '四级',
      }, {
        value: '2',
        label: '三级',
      }, {
        value: '3',
        label: '二级',
      }, {
        value: '4',
        label: '一级',
      }],
      option_location: regionData,
      text: '',
      textarea: '',
      msg: '',
      teachers:[],
      search: '',
      dialogFormVisible: false,
      select: '',
      form: {
        id: '',
        name: '',
        age: '',
        sex: '',
        school: '',
        education: '',
        phone: '',
        location: '',
        locations: [],
        working: '',
        birth: '',
        major: '',
        e_mail: '',
        nation: '',
        native_place: '',
        technical_post: '',
        english_level: '',
        computer_level: '',
        hobby: '',
        hobbys: [],
        motto: ''
      },
      formLabelWidth: '80px',
    }
  },
  created() {
    this.findAllTeachers();
  },
  watch:{
    teacherName () {
      this.findAllTeachers();
    }
  },
  methods: {
    handleSuccess (file) {
      const filename = file.name;
      this.$message({
        message: '文件上传成功！',
        type: 'success'
      });
    },
    searchTeacherByName: function () {
      if (this.teacherName !== '') {
        this.$axios.get("/teacher/findTeacherByName?name=" + this.teacherName).then((resp) => {
          this.teachers = resp.data;
        }).catch((error) => {
          this.$message({
            type: 'error',
            message: "查询失败，原因是" + error.data.message
          });
        })
      }
    },
    //批量删除教师的实现语句
    deleteTeachers () {
      this.$confirm('此操作将永久删除老师的数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        let ids = '?';
        this.multipleSelection.forEach( (item)=>{
          ids += 'ids='+item.uid+'&'
        });
        this.$axios.post("/teacher/deleteTeachersByIds"+ids).then( (resp)=> {
          if (resp) {
            this.findAllTeachers();
            this.$message.success("删除成功！");
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      console.log(val)
    },
    submitTeacher () {
      if (this.dialogStatus === "addTeacher"){
        this.addTeacher();
      } else if(this.dialogStatus === "editTeacher") {
        this.editTeacher();
      }
    },
    findAllTeachers () {
      this.$axios.get("/teacher/findAllTeachers")  //$axios与后台进行交互
          .then((res) => {
            this.teachers = res.data
            this.teachers.forEach((teacher)=> {
              if(teacher.hobby) {
                teacher.hobbys = teacher.hobby.split(",");
              }
              else {
                teacher.hobbys = [];
              }
              if(teacher.location) {
                teacher.locations = teacher.location.split(",");
              }
              else {
                teacher.locations = [];
              }
            })
          })
          .catch(error => {
            this.$message({
              type: 'error',
              message: "查询失败，原因是"+error.data.message
            });
          });
    },
    handleEdit (row) {
      this.dialogFormVisible = true;
      this.dialogStatus = "editTeacher";
      this.form.uid = row.uid;
      this.form.id = row.id;
      this.form.name = row.name;
      this.form.age = row.age;
      this.form.sex = row.sex;
      this.form.education = row.education;
      this.form.school = row.school;
      this.form.phone = row.phone;
      this.form.location = row.location;
      this.form.locations = row.location.split(",");
      this.form.working = row.working;
      this.form.birth = row.birth;
      this.form.major = row.major;
      this.form.e_mail = row.e_mail;
      this.form.nation = row.nation;
      this.form.native_place = row.native_place;
      this.form.technical_post = row.technical_post;
      this.form.English_level = row.English_level;
      this.form.computer_level = row.computer_level;
      this.form.hobby = row.hobby;
      this.form.hobbys = row.hobby.split(",");
      this.form.motto = row.motto;
    },
    handleDelete (row) {
      this.$confirm('此操作将永久删除该教师的数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$axios.post("/teacher/deleteTeacher?uid="+row.uid).then ((resp)=>{
          this.$message.success("删除成功!")
          this.findAllTeachers();
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },
    showDialog () {
      this.age = undefined;
      this.phone = undefined;
      this.dialogFormVisible = true;
      this.dialogStatus = "addTeacher";
    },
    addTeacher () {
      this.$refs.teacher.validate((valid) => {
        if (valid) {
            this.form.location = this.form.locations.join(",")
            this.form.hobby = this.form.hobbys.join(",")
          this.$axios.post("/teacher/addTeacher",this.form).then( (resp)=>{ //post返回promise对象，包括两个方法：then()和catch()
            if (resp.data.code !== -1) {  //产生错误信息时的代码为-1
              this.dialogFormVisible = false;
              this.$message.success("添加成功！");
              this.findAllTeachers();
            }
          }).catch((error)=>{
            this.$message({
              message: '添加数据失败，原因是'+error.data.message,
              type: 'error'
            })
          })
        } else {
          this.$message({
            message: '请输入所有字段',
            type: 'error'
          })
          return false;
        }
      });
    },
    editTeacher () {
      this.$refs.teacher.validate((valid) => {
        if (valid) {
          this.form.location = this.form.locations.join(",")
          this.form.hobby = this.form.hobbys.join(",");
          this.$axios.post("/teacher/updateTeacher",this.form).then( (resp)=>{
            if (resp.data.code!==-1) {  //callback
              this.dialogFormVisible = false;
              this.$message.success("编辑成功！");
              this.findAllTeachers();
            }
          }).catch( (error)=> {
            this.$message({
              message: '数据更新失败，原因是'+error.data.message,
              type: 'error'
            })
          })
        }else {
          this.$message({
            message: '请输入所有字段',
            type: 'error'
          })
          return false;
        }
      });
    },
    locationFormat:function (row,column) {
      let address = row[column.property];
      var addresses = address.split(',');
      var loc = "";
      for (let i = 0; i < addresses.length; i++) {
        loc += CodeToText[addresses[i]];
        loc += ",";
      }
      loc = loc.slice(0,loc.length-1);
      return loc;
    },
    dateformat:function (row, column) {
      let date = row[column.property];
      if (date == undefined) return '';
      let dt = new Date(date);
      return dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate()
    }
  }
}
</script>
<style scoped>
.table {
  margin: 0 auto;
  clear: both;
}
</style>
