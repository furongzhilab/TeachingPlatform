<template>
  <div class="test2">
    <el-button type="primary" style="margin-top: 20px" @click="upload">上传视频</el-button>
    <b-nav-item v-if="this.code == '200'">
      <div style="margin-top: 20px">
        <img src="../assets/img/commandpic5.jpg">
      </div>
    </b-nav-item>
    <b-nav-item v-if="videoForm.flag == '1'">
      <el-upload style="margin-left:14%;margin-top:5%"
                 class="avatar-uploader el-upload--text"
                 :drag="{Plus}"
                 action="http://localhost:8081/saveVideo/saveTest"
                 multiple
                 :show-file-list="false"
                 :data="{SavePath: this.Path.url}"
                 :on-success="handleVideoSuccess"
                 :before-upload="beforeUploadVideo"
                 :on-progress="uploadVideoProcess">
        <i v-if="Plus" class="el-icon-upload"></i>
        <div v-if="Plus" class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        <el-progress v-if="videoFlag == true" type="circle" :percentage="videoUploadPercent" style="margin-top:30px;"></el-progress>
        <div class="el-upload__tip" slot="tip">只能上传mp4/flv/avi文件，且不超过500M</div>
      </el-upload>
    </b-nav-item>
  </div>
</template>

<script>

export default {
  name: "Uploadvideo",
  data () {
    return {
      videoForm: {
        videoId: '',
        videoUrl: '',
        flag: ''
      },
      videoFlag: false,
      Plus: true,
      Path: {
        url: 'C:\\Users\\furongzhi\\Desktop\\video'
      },
      videoUploadPercent: 0
    }
  },
  mounted: function () {
  },
  methods: {
    upload() {
      this.videoForm.flag = '1'
    },
    // 视频上传前执行
    beforeUploadVideo (file) {
      const isLt500M = file.size / 1024 / 1024 < 500
      if (['video/mp4', 'video/ogg', 'video/flv', 'video/avi', 'video/wmv', 'video/rmvb'].indexOf(file.type) === -1) {
        this.$message.error('请上传正确的视频格式')
        return false
      }
      if (!isLt500M) {
        this.$message.error('上传视频大小不能超过500MB哦!')
        return false
      }
    },
    // 视频上传过程中执行
    uploadVideoProcess (event, file, fileList) {
      this.Plus = false
      this.videoFlag = true
      this.videoUploadPercent = file.percentage.toFixed(0)
    },
    // 视频上传成功是执行
    handleVideoSuccess (res, file) {
      this.Plus = false
      this.videoUploadPercent = 100
      console.log(res)
      // 如果为200代表视频保存成功
      if (res.resCode === '200') {
        this.code = '200'
        // 接收视频传回来的名称和保存地址
        // 至于怎么使用看你啦~
        this.videoForm.videoId = res.newVideoName
        this.videoForm.videoUrl = res.VideoUrl
        this.$message.success('视频上传成功！')
      } else {
        this.$message.error('视频上传失败，请重新上传！')
      }
    }
  }
}

</script>

  <style scoped>

  </style>