<template>
  <el-container style="height: 100%; margin: fill;">

    <!--#################################################################################-->
    <!--头部导航栏-->
    <el-header style="height: 80px;">
      <div style="width:230px; position: absolute;">
        <a href="" title="名师有享">
          <img src="../assets/img/logo05.png" width="220px" height="70px">
        </a>
      </div>
      <div style="position: absolute;margin-left: 270px;">
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px">
          <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
          <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px;">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item divided>
                <strong>小学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>编程</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>中学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>高中课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <el-link @click="teacher" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
          <el-link @click="message" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
          <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
          <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
          <el-input
              style="width: 230px; height: 100px; margin-left: 50px; margin-top: 10px"
              placeholder="请输入内容"
              v-model="input">
            <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
            <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
          </el-input>
          <b-nav-item v-if="user != null">
            <el-link @click="person" :underline="false" style="margin-left: 40px;font-size: 18px">个人中心</el-link>
            <div class="user-info">
              <el-dropdown trigger="click" @command="logout">
                <span>{{user.name}}<i class="el-icon-arrow-down el-icon--right"></i></span>
                <el-dropdown-menu slot="dropdown" class="user-info">
                  <el-dropdown-item command="logout">退出</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
          </b-nav-item>
        </el-tabs>
      </div>
    </el-header>

    <!--####################################################################################################################-->
    <!-- 内容 -->
    <div class="alert-box-item">
      <div class="bigImg-div" @click="toGetImg">
        <img class="bigImg" :src=valueUrl v-if="valueUrl">
        <div style="width: 40px;height: 40px"></div>
        <div style="color: rgba(255,255,255,0.7); margin-left: 20px">上传头像</div>
      </div>
      <div style="height: 10px"></div>
      <span style="font-size: 25px; margin-left: 180px; color: white">{{user.name}}</span>
    </div>

    <!--####################################################################################################################-->
    <!-- 底部  -->
    <el-footer style="background: black; width: 100%; height: 300px; color: white;">
      <div style="position: absolute">
        <img src="../assets/img/logo06.png" style="width: 220px;height: 70px;margin-top: 20px">
        <p style="font-size: 15px;color: #999;">由高教社联手网易推出，让每一个有提升愿望的用户能够学到免费的中小学课程，并获得认证</p>
      </div>
      <el-row class="foot-row" justify="space-between" style="margin-left: 750px; margin-top: 20px;margin-right: 40px;width: 600px">

        <el-col :span="20" style="font-size: 20px">
          <a>关于我们</a>
          <a style="margin-left: 300px">关注我们</a>
          <div style="margin-left: 365px;margin-top: 15px;position: absolute">
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weiboicon.jpg" width="55px" height="50px">
            </el-link>
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weixinicon.jpg" width="55px" height="50px" style="margin-left: 4px">
            </el-link>
          </div>
        </el-col>
      </el-row>

      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;">
        <el-col :span="10">
          <el-link href="" >关于我们</el-link>
          <el-link href="" style="margin-left: 25px">学校云</el-link>
          <el-link href="" style="margin-left: 28px">合作专区</el-link>
        </el-col>
      </el-row>

      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="" >联系我们</el-link>
          <el-link href="" style="margin-left: 20px">隐私政策</el-link>
          <el-link href="" style="margin-left: 20px">用户协议</el-link>
        </el-col>
      </el-row>

      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="">常见问题</el-link>
          <el-link href="" style="margin-left: 20px">法律条款</el-link>
          <el-link href="" style="margin-left: 20px">在线反馈</el-link>
        </el-col>
      </el-row>

      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;margin-bottom: 20px" >
        <el-col :span="10">
          <el-link href="">意见反馈</el-link>
          <el-link href="" style="margin-left: 20px">版权声明</el-link>
          <el-link href="" style="margin-left: 20px">网上有害信息举报</el-link>
        </el-col>
      </el-row>

      <div>
        <p style="font-size: 13px;color: #999;text-align: center">网上有害信息举报：网站 https://www.12377.cn 电话 010-58581010 邮箱 youdao_jubao@rd.netease.com</p>
        <el-link href="https://www.beianx.cn/info/16CD7AFD-FCBE-4361-859A-C6031989E89A.html" style="margin-left: 460px">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602000207">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="https://beian.tianyancha.com/ic5ea124352063">粤B2-20090191-26</el-link>
        <p style="font-size: 13px;color: #999;text-align: center">Copyright © 2021</p>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
let inputElement = null
export default {
  name: "Uploadvideo",
  data() {
    return {
      user: JSON.parse(window.sessionStorage.getItem("user")),
      valueUrl: '',
      activeIndex:'1',
      input: '',
    }
  },
  computed: {
    routes () {
      return this.$store.state.routes;
    }
  },
  methods: {
    init () {
      this.$router.replace("/")
    },
    login () {
      this.$router.replace("/login")
    },
    register() {
      this.$router.replace("/register")
    },
    person () {
      this.$router.replace("/person")
    },
    course () {
      this.$router.replace("/course")
    },
    teacher () {
      this.$router.replace("/teacher")
    },
    message() {
      this.$router.replace("/message")
    },
    information() {
      this.$router.replace("/information")
    },
    aboutus () {
      this.$router.replace("/aboutus")
    },
    handleClick(tab, event) {
      console.log(tab, event);
    },
    menuClick (index) {
      this.$router.push(index);
    },
    logout (data) {
      if (data === 'logout') {
        this.$confirm('您确定要退出吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$axios.get("/logout").then((res) => {
          })
          window.sessionStorage.removeItem('user')
          this.$store.commit("findAllRoutes", [])
          this.$router.replace("/")
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消退出'
          });
        });
      }
    },
    toGetImg() {
      if (inputElement === null) {
        // 生成文件上传的控件
        inputElement = document.createElement('input')
        inputElement.setAttribute('type', 'file')
        inputElement.style.display = 'none'

        if (window.addEventListener) {
          inputElement.addEventListener('change', this.uploadFile, false)
        } else {
          inputElement.attachEvent('onchange', this.uploadFile)
        }

        document.body.appendChild(inputElement)
      }
      inputElement.click()
    },
    uploadFile(el) {
      if (el && el.target && el.target.files && el.target.files.length > 0) {
        console.log(el)
        const files = el.target.files[0]
        const isLt2M = files.size / 1024 / 1024 < 2
        const size = files.size / 1024 / 1024
        console.log(size)
        // 判断上传文件的大小
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!')
        } else if (files.type.indexOf('image') === -1) { //如果不是图片格式
          // this.$dialog.toast({ mes: '请选择图片文件' });
          this.$message.error('请选择图片文件');
        } else {
          const that = this;
          const reader = new FileReader(); // 创建读取文件对象
          reader.readAsDataURL(el.target.files[0]); // 发起异步请求，读取文件
          reader.onload = function() { // 文件读取完成后
            // 读取完成后，将结果赋值给img的src
            that.valueUrl = this.result;
            console.log(this.result);
            // 数据传到后台
            //const formData = new FormData()
            //formData.append('file', files); // 可以传到后台的数据
          };
        }
      }
    }
  },
  beforeDestroy() {
    if (inputElement) {
      if (window.addEventListener) {
        inputElement.removeEventListener('change', this.onGetLocalFile, false)
      } else {
        inputElement.detachEvent('onchange', this.onGetLocalFile)
      }
      document.body.removeChild(inputElement)
      inputElement = null
      console.log('========inputelement destroy')
    }
  }
}
</script>

<style scoped>
.user-info {
  width: 100px;
  margin-top: -90px;
  margin-left: 1000px;
  font-size: 18px;
  cursor: pointer;
}

.alert-box-item {
  overflow: hidden;
  width: 100%;
  height: 180px;
  margin-top: 10px;
  background-color: palegreen;
}

.bigImg-div {
  width: 100px;
  height: 100px;
  margin-top: 30px;
  margin-left: 180px;
  border-radius: 100%;
  overflow: hidden;
  border: 1px solid #ddd;
}

.bigImg {
  display: block;
  width: 100px;
  height: 100px;
  border-radius: 100%;
}
</style>