<template>
  <!--高一上册-->
  <el-container style="height: 100%; margin: fill;">
    <!--####################################################################################################################-->
    <!--头部导航栏-->
    <el-header style="height: 80px;">
      <div style="width:230px; position: absolute;">
        <a href="" title="名师有享">
          <img src="../assets/img/logo05.png" width="220px" height="70px">
        </a>
      </div>
      <div style="position: absolute;margin-left: 270px;margin-top: 0px;">
        <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px;">
          <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
          <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
            <el-dropdown-menu slot="dropdown" style="margin-left: 100px">
              <el-dropdown-item divided>
                <strong>小学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>编程</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>中学课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
              <el-dropdown-item divided>
                <strong>高中课程</strong>
                <el-row>
                  <el-button round>语文</el-button>
                  <el-button round>数学</el-button>
                  <el-button round>英语</el-button>
                  <el-button round>物理</el-button>
                  <el-button round>化学</el-button>
                  <el-button round>生物</el-button>
                  <el-button round>地理</el-button>
                </el-row>
                <el-row>
                  <el-button round>政治</el-button>
                  <el-button round>历史</el-button>
                  <el-button round>信息技术</el-button>
                  <el-button round>通用技术</el-button>
                </el-row>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

          <el-link @click="teacherteam" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
          <el-link @click="livecommunity" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
          <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
          <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
          <el-input
              style="width: 230px; height: 100px; margin-left: 130px; margin-top: 10px"
              placeholder="请输入内容"
              v-model="input">
            <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
            <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
          </el-input>
          <el-link target="_blank" @click="login" style="margin-left: 30px">登录</el-link>
          <a style="margin-left: 5px"> | </a>
          <el-link target="_blank" style="margin-left: 5px">注册</el-link>
        </el-tabs>
      </div>
    </el-header>

    <!--####################################################################################################################-->
    <!--内容-->
    <!--    <el-main style="background: #F0F0F0; #545c64">-->
    <el-main style="background: #F0F0F0;">
      <el-tabs v-model="activeIndex" @tab-click="handleClick" style="margin-left: 10px;margin-right: 20px">
        <el-tab-pane label="小学" name="1" style="width: 1800px;height: 600px">
          <div>
            <el-col :span="4" style="margin-top: 10px;">
              <el-menu
                  default-active="1"
                  class="el-menu-vertical-demo"
                  @open="handleOpen"
                  @close="handleClose"
                  background-color="#DCDCDC"
                  text-color="#000000"
                  active-text-color="#ffd04b">
                <el-submenu index="1">
                  <template slot="title">
                    <i class="el-icon-notebook-2"></i>
                    <span>一年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="1-1">上册</el-menu-item>
                    <el-menu-item index="1-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-submenu index="2">
                  <template slot="title">
                    <i class="el-icon-notebook-1"></i>
                    <span>二年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="2-1">上册</el-menu-item>
                    <el-menu-item index="2-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-submenu index="3">
                  <template slot="title">
                    <i class="el-icon-notebook-2"></i>
                    <span>三年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="3-1">上册</el-menu-item>
                    <el-menu-item index="3-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-submenu index="4">
                  <template slot="title">
                    <i class="el-icon-notebook-1"></i>
                    <span>四年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="4-1">上册</el-menu-item>
                    <el-menu-item index="4-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-submenu index="5">
                  <template slot="title">
                    <i class="el-icon-reading"></i>
                    <span>五年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="5-1">上册</el-menu-item>
                    <el-menu-item index="5-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-submenu index="6">
                  <template slot="title">
                    <i class="el-icon-suitcase"></i>
                    <span>六年级</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="6-1">上册</el-menu-item>
                    <el-menu-item index="6-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
              </el-menu>
            </el-col>
          </div>

          <div style="position: absolute;margin-left: 230px;margin-right: 25px; margin-top: 10px;width: 1100px;height: 70px;">
            <el-menu
                :default-active="activeSubject"
                class="el-menu-demo"
                mode="horizontal"
                @select="handleSelect"
                background-color="#DCDCDC"
                text-color="	#696969"
                active-text-color="#ffd04b"
                style="height: 50px;">
              <el-menu-item index="1" style="font-size: 15px;margin-left: 10px;height: 50px;">全部</el-menu-item>
              <el-menu-item index="2" style="font-size: 15px;margin-left: 10px;height: 50px">语文</el-menu-item>
              <el-menu-item index="3" style="font-size: 15px;margin-left: 10px;height: 50px">数学</el-menu-item>
              <el-menu-item index="4" style="font-size: 15px;margin-left: 10px;height: 50px">英语</el-menu-item>
            </el-menu>
            <!--课程-->
            <el-row :gutter="5" style="margin-top: 18px;">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon6.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon7.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="5">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon6.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon7.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>

        <el-tab-pane label="初中" name="2" style="width: 1800px;height: 600px">
          <div>
            <el-col :span="4" style="margin-top: 10px;">
              <el-menu
                  default-active="1"
                  class="el-menu-vertical-demo"
                  @open="handleOpen"
                  @close="handleClose"
                  background-color="#DCDCDC"
                  text-color="#000000"
                  active-text-color="#ffd04b">
                <el-submenu index="1">
                  <template slot="title">
                    <i class="el-icon-notebook-2"></i>
                    <span>初一</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="1-1">上册</el-menu-item>
                    <el-menu-item index="1-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-menu-item index="2">
                  <i class="el-icon-notebook-1"></i>
                  <span slot="title">初二</span>
                </el-menu-item>
                <el-menu-item index="3">
                  <i class="el-icon-reading"></i>
                  <span slot="title">初三</span>
                </el-menu-item>
              </el-menu>
            </el-col>
          </div>

          <div style="position: absolute;margin-left: 230px;margin-right: 25px; margin-top: 10px;width: 1100px;height: 70px;">
            <el-menu
                :default-active="activeSubject"
                class="el-menu-demo"
                mode="horizontal"
                @select="handleSelect"
                background-color="#DCDCDC"
                text-color="	#696969"
                active-text-color="#ffd04b"
                style="height: 50px;">
              <el-menu-item index="1" style="font-size: 15px;margin-left: 10px;height: 50px;">全部</el-menu-item>
              <el-menu-item index="2" style="font-size: 15px;margin-left: 10px;height: 50px">语文</el-menu-item>
              <el-menu-item index="3" style="font-size: 15px;margin-left: 10px;height: 50px">数学</el-menu-item>
              <el-menu-item index="4" style="font-size: 15px;margin-left: 10px;height: 50px">英语</el-menu-item>
              <el-menu-item index="5" style="font-size: 15px;margin-left: 10px;height: 50px">物理</el-menu-item>
              <el-menu-item index="6" style="font-size: 15px;margin-left: 10px;height: 50px">化学</el-menu-item>
              <el-menu-item index="7" style="font-size: 15px;margin-left: 10px;height: 50px">生物</el-menu-item>
              <el-menu-item index="8" style="font-size: 15px;margin-left: 10px;height: 50px">地理</el-menu-item>
              <el-menu-item index="9" style="font-size: 15px;margin-left: 10px;height: 50px">政治</el-menu-item>
              <el-menu-item index="10" style="font-size: 15px;margin-left: 10px;height: 50px">历史</el-menu-item>
            </el-menu>
            <!--课程-->
            <el-row :gutter="5" style="margin-top: 18px;">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon6.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon7.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="5">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon6.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon7.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
          </div>

        </el-tab-pane>

        <el-tab-pane label="高中" name="3" style="width: 1800px;height: 650px">
          <div>
            <el-col :span="4" style="margin-top: 10px;">
              <el-menu
                  default-active="1"
                  class="el-menu-vertical-demo"
                  @open="handleOpen"
                  @close="handleClose"
                  background-color="#DCDCDC"
                  text-color="#000000"
                  active-text-color="#ffd04b">
                <el-submenu index="1">
                  <template slot="title">
                    <i class="el-icon-notebook-2"></i>
                    <span>高一</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="1-1" @click="senioronefirst">上册</el-menu-item>
                    <el-menu-item index="1-2">下册</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
                <el-menu-item index="2">
                  <i class="el-icon-notebook-1"></i>
                  <span slot="title">高二</span>
                </el-menu-item>
                <el-menu-item index="3">
                  <i class="el-icon-reading"></i>
                  <span slot="title">高三</span>
                </el-menu-item>
              </el-menu>
            </el-col>
          </div>

          <!--          <div style="position: absolute;margin-left: 230px;margin-right: 25px; margin-top: 10px;width: 1100px;height: 70px;background: #409eff">-->
          <div style="position: absolute;margin-left: 230px;margin-right: 25px; margin-top: 10px;width: 1100px;height: 70px;">
            <el-menu
                :default-active="activeSubject"
                class="el-menu-demo"
                mode="horizontal"
                @select="handleSelect"
                background-color="#DCDCDC"
                text-color="	#696969"
                active-text-color="#ffd04b"
                style="height: 50px;">
              <el-menu-item index="1" style="font-size: 15px;margin-left: 10px;height: 50px;">全部</el-menu-item>
              <el-menu-item index="2" style="font-size: 15px;margin-left: 10px;height: 50px">语文</el-menu-item>
              <el-menu-item index="3" style="font-size: 15px;margin-left: 10px;height: 50px">数学</el-menu-item>
              <el-menu-item index="4" style="font-size: 15px;margin-left: 10px;height: 50px">英语</el-menu-item>
              <el-menu-item index="5" style="font-size: 15px;margin-left: 10px;height: 50px">物理</el-menu-item>
              <el-menu-item index="6" style="font-size: 15px;margin-left: 10px;height: 50px">化学</el-menu-item>
              <el-menu-item index="7" style="font-size: 15px;margin-left: 10px;height: 50px">生物</el-menu-item>
              <el-menu-item index="8" style="font-size: 15px;margin-left: 10px;height: 50px">地理</el-menu-item>
              <el-menu-item index="9" style="font-size: 15px;margin-left: 10px;height: 50px">政治</el-menu-item>
              <el-menu-item index="10" style="font-size: 15px;margin-left: 10px;height: 50px">历史</el-menu-item>
            </el-menu>

            <!--课程-->
            <el-row :gutter="5" style="margin-top: 18px;">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon6.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 210px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon7.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
              <el-col style="width: 220px;margin-left: 8px">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon8.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
            </el-row>
            <el-row :gutter="5">
              <el-col :span="4" style="width: 210px;">
                <el-link href="" :underline="false">
                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;">
                    <div style="margin-top: 10px;margin-left: 3px">
                      <img src="../assets/img/tcicon5.png" style="width: 20%;">
                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>
                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>
                    </div>
                  </el-card>
                </el-link>
              </el-col>
<!--              <el-col style="width: 210px;margin-left: 8px">-->
<!--                <el-link href="" :underline="false">-->
<!--                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px;width: 200px">-->
<!--                    <div style="margin-top: 10px;margin-left: 3px">-->
<!--                      <img src="../assets/img/tcicon6.png" style="width: 20%;">-->
<!--                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>-->
<!--                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>-->
<!--                    </div>-->
<!--                  </el-card>-->
<!--                </el-link>-->
<!--              </el-col>-->
<!--              <el-col style="width: 210px;margin-left: 8px">-->
<!--                <el-link href="" :underline="false">-->
<!--                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">-->
<!--                    <div style="margin-top: 10px;margin-left: 3px">-->
<!--                      <img src="../assets/img/tcicon7.png" style="width: 20%;">-->
<!--                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>-->
<!--                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>-->
<!--                    </div>-->
<!--                  </el-card>-->
<!--                </el-link>-->
<!--              </el-col>-->
<!--              <el-col style="width: 220px;margin-left: 8px">-->
<!--                <el-link href="" :underline="false">-->
<!--                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">-->
<!--                    <div style="margin-top: 10px;margin-left: 3px">-->
<!--                      <img src="../assets/img/tcicon8.png" style="width: 20%;">-->
<!--                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>-->
<!--                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>-->
<!--                    </div>-->
<!--                  </el-card>-->
<!--                </el-link>-->
<!--              </el-col>-->
<!--              <el-col style="width: 220px;margin-left: 8px">-->
<!--                <el-link href="" :underline="false">-->
<!--                  <el-card :body-style="{ padding: '0px' }" shadow="hover" style="height: 250px">-->
<!--                    <div style="margin-top: 10px;margin-left: 3px">-->
<!--                      <img src="../assets/img/tcicon8.png" style="width: 20%;">-->
<!--                      <span style="margin-left: 15px;margin-top:0px;position: absolute">课程内容</span>-->
<!--                      <span style="margin-left: 15px; font-size: 15px;color: #999;">教师姓名</span>-->
<!--                    </div>-->
<!--                  </el-card>-->
<!--                </el-link>-->
<!--              </el-col>-->
            </el-row>
          </div>
        </el-tab-pane>

      </el-tabs>

    </el-main>

    <!--####################################################################################################################-->
    <!-- 底部  -->
    <el-footer style="background: #272727; height: 300px; color: white">
      <div style="position: absolute">
        <img src="../assets/img/logo06.png" style="width: 220px;height: 70px;margin-top: 20px">
        <p style="font-size: 15px;color: #999;">由高教社联手网易推出，让每一个有提升愿望的用户能够学到免费的中小学课程，并获得认证</p>
      </div>
      <el-row class="foot-row" justify="space-between" style="margin-left: 750px; margin-top: 20px;margin-right: 40px;width: 600px">
        <el-col :span="20" style="font-size: 20px">
          <a>关于我们</a>
          <a style="margin-left: 300px">关注我们</a>
          <div style="margin-left: 365px;margin-top: 15px;position: absolute">
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weiboicon.jpg" width="55px" height="50px">
            </el-link>
            <el-link href="https://weibo.com/" :underline="false">
              <img src="../assets/img/weixinicon.jpg" width="55px" height="50px" style="margin-left: 4px">
            </el-link>
          </div>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;">
        <el-col :span="10">
          <el-link href="" >关于我们</el-link>
          <el-link href="" style="margin-left: 25px">学校云</el-link>
          <el-link href="" style="margin-left: 28px">合作专区</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="" >联系我们</el-link>
          <el-link href="" style="margin-left: 20px">隐私政策</el-link>
          <el-link href="" style="margin-left: 20px">用户协议</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px ">
        <el-col :span="10">
          <el-link href="">常见问题</el-link>
          <el-link href="" style="margin-left: 20px">法律条款</el-link>
          <el-link href="" style="margin-left: 20px">在线反馈</el-link>
        </el-col>
      </el-row>
      <el-row class="foot-row" justify="space-between" style="margin-left: 700px;margin-bottom: 20px" >
        <el-col :span="10">
          <el-link href="">意见反馈</el-link>
          <el-link href="" style="margin-left: 20px">版权声明</el-link>
          <el-link href="" style="margin-left: 20px">网上有害信息举报</el-link>
        </el-col>
      </el-row>
      <div>
        <p style="font-size: 13px;color: #999;text-align: center">网上有害信息举报：网站 https://www.12377.cn 电话 010-58581010 邮箱 youdao_jubao@rd.netease.com</p>
        <el-link href="https://www.beianx.cn/info/16CD7AFD-FCBE-4361-859A-C6031989E89A.html" style="margin-left: 460px">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602000207">京ICP备12020869号-2</el-link>
        <a style="color: #999"> | </a>
        <el-link href="https://beian.tianyancha.com/ic5ea124352063">粤B2-20090191-26</el-link>
        <p style="font-size: 13px;color: #999;text-align: center">Copyright © 2021</p>
      </div>
    </el-footer>
  </el-container>
</template>

<script>
export default {
  name: "SeniorOneFirst",
  data() {
    return {
      input: '',
      activeIndex: '1',
      activeSubject: '1',
    };
  },
  mounted() {
    window.addEventListener("scroll",this.watchScroll);
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
    watchScroll() {
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
      if (scrollTop > 49) {
        this.navBarFixed = true
      } else {
        this.navBarFixed = false
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    init () {
      this.$router.replace("/init")
    },
    login () {
      this.$router.replace("/login")
    },
    course () {
      this.$router.replace("/course")
    },
    teacherteam () {
      this.$router.replace("/teacherteam")
    },
    livecommunity() {
      this.$router.replace("/livecommunity")
    },
    information() {
      this.$router.replace("/information")
    },
    aboutus () {
      this.$router.replace("/aboutus")
    },
    senioronefirst () {
      this.$router.replace("/senioronefirst")
    },

  }
}
</script>

<style scoped>
.foot-row {
  margin-top: 10px;
}
</style>