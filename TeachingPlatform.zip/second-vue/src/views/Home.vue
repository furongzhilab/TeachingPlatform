<template>
  <div>
    <el-container style="height: 100%; margin: fill;">
      <!--#################################################################################-->
      <!--头部导航栏-->
      <el-header style="height: 80px;">
        <div style="width:230px; position: absolute;">
          <a href="" title="名师有享">
            <img src="../assets/img/logo05.png" width="220px" height="70px">
          </a>
        </div>
        <div style="position: absolute;margin-left: 270px;">
          <el-tabs v-model="activeIndex" @tab-click="handleClick" style="width: 1100px">
            <el-link @click="init" :underline="false" style="font-size: 18px;">首页</el-link>
            <el-dropdown>
          <span class="el-dropdown-link" style="cursor: pointer;color: black;font-size: 16px;margin-left: 40px;">
            <el-link @click="course" :underline="false" style="font-size: 18px;">课程分类</el-link>
            <i class="el-icon-arrow-down el-icon--right" style="font-size: 12px"></i>
          </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item divided>
                  <strong>小学课程</strong>
                  <el-row>
                    <el-button round>语文</el-button>
                    <el-button round>数学</el-button>
                    <el-button round>英语</el-button>
                    <el-button round>编程</el-button>
                  </el-row>
                </el-dropdown-item>
                <el-dropdown-item divided>
                  <strong>中学课程</strong>
                  <el-row>
                    <el-button round>语文</el-button>
                    <el-button round>数学</el-button>
                    <el-button round>英语</el-button>
                    <el-button round>物理</el-button>
                    <el-button round>化学</el-button>
                    <el-button round>生物</el-button>
                    <el-button round>地理</el-button>
                  </el-row>
                  <el-row>
                    <el-button round>政治</el-button>
                    <el-button round>历史</el-button>
                    <el-button round>信息技术</el-button>
                    <el-button round>通用技术</el-button>
                  </el-row>
                </el-dropdown-item>
                <el-dropdown-item divided>
                  <strong>高中课程</strong>
                  <el-row>
                    <el-button round>语文</el-button>
                    <el-button round>数学</el-button>
                    <el-button round>英语</el-button>
                    <el-button round>物理</el-button>
                    <el-button round>化学</el-button>
                    <el-button round>生物</el-button>
                    <el-button round>地理</el-button>
                  </el-row>
                  <el-row>
                    <el-button round>政治</el-button>
                    <el-button round>历史</el-button>
                    <el-button round>信息技术</el-button>
                    <el-button round>通用技术</el-button>
                  </el-row>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>

            <el-link @click="teacher" :underline="false" style="margin-left: 40px;font-size: 18px;">师资力量</el-link>
            <el-link @click="message" :underline="false" style="margin-left: 40px;font-size: 18px;">直播社区</el-link>
            <el-link @click="information" :underline="false" style="margin-left: 40px;font-size: 18px;">留言板</el-link>
            <el-link @click="aboutus" :underline="false" style="margin-left: 40px;font-size: 18px;">关于我们</el-link>
            <el-input
                style="width: 230px; height: 100px; margin-left: 50px; margin-top: 10px"
                placeholder="请输入内容"
                v-model="input">
              <i slot="suffix" class="el-input__icon el-icon-search" style="height: 44px"></i>
              <!--          <el-button slot="suffix" icon="el-icon-search" type="success"></el-button>-->
            </el-input>
            <b-nav-item v-if="user != null">
              <el-link @click="person" :underline="false" style="margin-left: 40px;font-size: 18px">个人中心</el-link>
              <div class="user-info">
                <el-dropdown trigger="click" @command="logout">
                  <span>{{user.name}}<i class="el-icon-arrow-down el-icon--right"></i></span>
                  <el-dropdown-menu slot="dropdown" class="user-info">
                    <el-dropdown-item command="logout">退出</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </div>
            </b-nav-item>
          </el-tabs>
        </div>
      </el-header>

      <!--####################################################################################################################-->
      <!-- 内容 -->
      <div class="alert-box-item" :style="note">
        <div class="bigImg-div" @click="toGetImg">
          <img class="bigImg" :src=valueUrl v-if="valueUrl">
          <div style="width: 40px;height: 40px;"></div>
          <div style="color: rgba(255,255,255,0.7); margin-left: 15px;">上传头像</div>
        </div>
<!--        <div style="height: 10px;"></div>-->
<!--        <span style="font-size: 25px; margin-left: 180px; color: white;">{{user.name}}</span>-->
        <div style="margin-top: 5px">
          <span style="font-size: 19px; margin-left: 100px; color: white;">{{user.username}}</span>
          <span style="font-size: 15px; margin-left: 5px; color: white;">{{user.username}}</span>
        </div>
      </div>

      <el-container>
        <el-aside width="200px">
          <el-menu @select="menuClick">
            <el-submenu :index="index+''" v-for="(item,index) in routes" v-if="!item.hidden" :key="index">
              <template slot="title">
                <i class="el-icon-location"></i>
                <span>{{item.name}}</span>
              </template>
              <el-menu-item :index="item2.path" v-for="(item2,index) in item.children" :key="index">{{item2.name}}</el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main>
          <el-breadcrumb separator="/login" v-if="this.$router.currentRoute.path!=='/home'">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item><a href="/login">{{this.$router.currentRoute.name}}</a></el-breadcrumb-item>
          </el-breadcrumb>
<!--          <div v-if="this.$router.currentRoute.path === '/home'">重庆师范大学</div>-->
          <div v-if="this.$router.currentRoute.path === '/home'">名师有享</div>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>
<script>
let inputElement = null
  export default {
    name: 'Home',
    data () {
      return {
        user: JSON.parse(window.sessionStorage.getItem("user")),
        valueUrl: '',
        activeIndex:'1',
        input: '',
        note: {
          backgroundImage: "url(" + require("../assets/img/background/bg8.jpg") + ")",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          height: "150px"
        },
      }
    },
    computed: {
      routes () {
        return this.$store.state.routes;
      }
    },
    methods: {
      init () {
        this.$router.replace("/")
      },
      login () {
        this.$router.replace("/login")
      },
      register() {
        this.$router.replace("/register")
      },
      person () {
        this.$router.replace("/person")
      },
      course () {
        this.$router.replace("/course")
      },
      teacher () {
        this.$router.replace("/teacher")
      },
      message() {
        this.$router.replace("/message")
      },
      information() {
        this.$router.replace("/information")
      },
      aboutus () {
        this.$router.replace("/aboutus")
      },
      handleClick(tab, event) {
        console.log(tab, event);
      },
      menuClick (index) {
        this.$router.push(index);
      },
      logout (data) {
        if (data === 'logout') {
          this.$confirm('您确定要退出吗?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.$axios.get("/logout").then((res) => {
            })
            window.sessionStorage.removeItem('user')
            this.$store.commit("findAllRoutes", [])
            this.$router.replace("/")
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消退出'
            });
          });
        }
      },
      toGetImg() {
        if (inputElement === null) {
          // 生成文件上传的控件
          inputElement = document.createElement('input')
          inputElement.setAttribute('type', 'file')
          inputElement.style.display = 'none'

          if (window.addEventListener) {
            inputElement.addEventListener('change', this.uploadFile, false)
          } else {
            inputElement.attachEvent('onchange', this.uploadFile)
          }

          document.body.appendChild(inputElement)
        }
        inputElement.click()
      },
      uploadFile(el) {
        if (el && el.target && el.target.files && el.target.files.length > 0) {
          console.log(el)
          const files = el.target.files[0]
          const isLt2M = files.size / 1024 / 1024 < 2
          const size = files.size / 1024 / 1024
          console.log(size)
          // 判断上传文件的大小
          if (!isLt2M) {
            this.$message.error('上传头像图片大小不能超过 2MB!')
          } else if (files.type.indexOf('image') === -1) { //如果不是图片格式
            // this.$dialog.toast({ mes: '请选择图片文件' });
            this.$message.error('请选择图片文件');
          } else {
            const that = this;
            const reader = new FileReader(); // 创建读取文件对象
            reader.readAsDataURL(el.target.files[0]); // 发起异步请求，读取文件
            reader.onload = function() { // 文件读取完成后
              // 读取完成后，将结果赋值给img的src
              that.valueUrl = this.result;
              console.log(this.result);
              // 数据传到后台
              //const formData = new FormData()
              //formData.append('file', files); // 可以传到后台的数据
            };
          }
        }
      }
    },
    beforeDestroy() {
      if (inputElement) {
        if (window.addEventListener) {
          inputElement.removeEventListener('change', this.onGetLocalFile, false)
        } else {
          inputElement.detachEvent('onchange', this.onGetLocalFile)
        }
        document.body.removeChild(inputElement)
        inputElement = null
        console.log('========inputelement destroy')
      }
    }
  }
</script>

<style scoped>
.user-info {
  width: 100px;
  margin-top: -90px;
  margin-left: 1000px;
  font-size: 18px;
  cursor: pointer;
}

.alert-box-item {
  overflow: hidden;
  width: 100%;
  height: 180px;
  margin-top: 10px;
}

.bigImg-div {
  width: 100px;
  height: 100px;
  /*margin-top: 30px;*/
  /*margin-left: 180px;*/
  margin-top: 15px;
  margin-left: 80px;
  border-radius: 100%;
  overflow: hidden;
  border: 1px solid #ddd;
}

.bigImg {
  display: block;
  width: 100px;
  height: 100px;
  border-radius: 100%;
}
</style>