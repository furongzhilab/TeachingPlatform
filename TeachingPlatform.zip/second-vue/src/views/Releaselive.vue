<template>
  <div style="margin-top: 20px">
    <div>
      <el-button type="primary" style="margin-left:10px;margin-bottom: 20px;" @click="addLive">发布直播信息</el-button>
    </div>
    <div>
      <el-table
          :data="liveData"
          border
          style="width: 100%">
        <el-table-column
            prop="id"
            label="ID"
            width="50">
        </el-table-column>
        <el-table-column
            prop="title"
            label="直播标题"
            width="120">
        </el-table-column>
        <el-table-column
            prop="content"
            label="直播内容"
            width="180">
        </el-table-column>
        <el-table-column
            prop="type"
            label="直播类别">
        </el-table-column>
        <el-table-column
            prop="date"
            label="直播时间">
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary"
                size="mini"
                @click="addLive">发布直播信息</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
      <el-dialog :title="dialogTitle[dialogStatus]" :visible.sync="dialogFormVisible" center>
        <el-form :model="live" :rules="rules" ref="live">
          <el-form-item label="直播标题" :label-width="formLabelWidth" prop="title">
            <el-input v-model="live.title" autocomplete="off" placeholder="请输入标题"></el-input>
          </el-form-item>
          <el-form-item label="直播内容" :label-width="formLabelWidth" prop="content">
            <el-input v-model="live.content" placeholder="请输入内容"></el-input>
          </el-form-item>
          <el-form-item label="直播类别" prop="type">
            <el-select v-model="live.type" placeholder="请选择直播类别">
              <el-option label="小学语文" value="小学语文"></el-option>
              <el-option label="小学数学" value="小学数学"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="预播时间" :label-width="formLabelWidth" prop="date">
            <el-col :span="12">
              <el-date-picker
                  style="width: 100%"
                  v-model="live.date"
                  type="date"
                  placeholder="选择日期"
                  value-format="yyyy-MM-dd">
              </el-date-picker>
            </el-col>
            <el-col class="line" :span="2.5"></el-col>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="submitForm">确 定</el-button>
        </div>
      </el-dialog>
  </div>
</template>

<script>

import { regionData, CodeToText } from "element-china-area-data"

export default {
  name: "Releaselive",
  data () {
    return {
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      liveData:[],
      option_location: regionData,
      dialogTitle: {
        addLive: "发布直播信息"
      },
      dialogStatus: "",
      dialogFormVisible: false,
      live:{
        title: '',
        content: '',
        type: '',
        date: ''
      },
      formLabelWidth: "120px",
      rules: {
        title: [
          { required: true, message: '请输入直播标题', trigger: 'blur' }
        ],
        content: [
          { required: true, message: '请输入直播内容', trigger: 'blur' }
        ],
        date: [
          { required: true, message: '请选择预播时间', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '请选择直播类别', trigger: 'blur' }
        ]
      },
    }
  },
  created() {
    this.findAllLives();
  },
  methods: {
    submitForm() {
      if (this.dialogStatus === 'addLive'){
        this.submit();
      }
    },
    submit () {
      this.$axios.post("/live/addLive",this.live).then( (resp)=>{
        if (resp) {
          this.dialogFormVisible = false;
          this.live = {}
          this.$message.success("添加成功！");
          this.findAllLives();
        }
      }).catch((error)=>{
        this.$message({
          message: '添加数据失败，原因是'+error.data.message,
          type: 'error'
        })
      })
    },
    addLive () {
      this.dialogFormVisible = true;
      this.dialogStatus = "addLive";
    },
    findAllLives () {
      this.$axios.get("live/findAllLives").then ( (resp)=>{
        this.liveData = resp.data
      }).catch( (error)=>{
        this.$message({
          type: 'error',
          message: "查询失败，原因是"+error.data.message
        });
      })
    },
    locationFormat:function (row,column) {
      let address = row[column.property];
      var addresses = address.split(',');
      var loc = "";
      for (let i = 0; i < addresses.length; i++) {
        loc += CodeToText[addresses[i]];
        loc += ",";
      }
      loc = loc.slice(0,loc.length-1);
      return loc;
    },
    dateformat:function (row, column) {
      let date = row[column.property];
      if (date == undefined) return '';
      let dt = new Date(date);
      return dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate()
    }
  }
}
</script>

<style scoped>

</style>