<template>
  <el-container>
    <el-header class="headerlogin" style="height: 150px">
      <img class="redlogo" src="../assets/img/logo05.png" style="margin-left: 40px;width:280px;height: 100px"/>
<!--      <div class="title" style="margin-left: 340px">中小学教辅平台</div>-->
    </el-header>
    <div class="background">
      <img src="../assets/img/background01.jpg" width="100%" height="110%" alt=""/>
    </div>
    <div class="login_bg">
      <el-form :model="registForm"  :rules="rules" ref="userForm" class="register">  <!-- ":"代表绑定，model绑定数据 -->
        <el-form-item prop="username">
          <el-input type="text" v-model="registForm.username" placeholder="请输入用户名" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="registForm.password" autocomplete="off" placeholder="请输入密码"></el-input>
        </el-form-item>
        <el-form-item prop="password2">
          <el-input type="password" v-model="registForm.password2" autocomplete="off" placeholder="请再次输入密码" @keydown.enter.native="register"></el-input>
        </el-form-item>
        <el-form-item>
          <el-radio v-model="radio" style="margin-left: 25px" label="1">我是老师</el-radio>
          <el-radio v-model="radio" style="margin-left: 12px" label="2">我是学生</el-radio>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" style="width: 40%; margin-left: 10px" @click="register()">注册</el-button>
          <router-link to="/login">
            <el-button type="text" style="width: 40%; margin-left: 30px; text-decoration: underline; font-size: 16px">现在登录</el-button>
          </router-link>
        </el-form-item>
      </el-form>
    </div>
  </el-container>
</template>

<script>
export default {
  name: 'Register',
  data() {
    return {
      rules: {
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        password2: [{ required: true, message: '请再次输入密码', trigger: 'blur' }]
      },
      registForm: {
        username: "",
        password: "",
        password2: ""
      },
      radio: '1'
    }
  },
  created() {

  },
  methods: {
    register() {
      let fd = new FormData();
      fd.append("username", this.registForm.username);
      fd.append("passwd", this.registForm.password);
      fd.append("radio", this.radio)

      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }

      if (this.registForm.password === this.registForm.password2) {
        this.$axios.post("/user/register", fd, config).then(res => {
          alert(res.data.message)
          if (res.data.code === 200) {
            // 回到登录界面
            this.$router.push({
              path: 'login'
            })
          }
        }).catch(error => {
          alert(error.data.message)
        })
      } else {
        alert("两次输入的密码不同")
      }
    },
  }
}
</script>

<!-- 添加“scoped”属性以将CSS仅限于此组件 -->
<style scoped>
.background{
  width: 100%;
  height: 75%;
  margin: 110px auto;
  z-index: -1;
  position: absolute;
}
.title {
  font-size: 30px;
  font-family: 华文隶书;
  color: #000;
  margin: -20px 0px 0px 430px;
}
.register {
  width: 270px;
  border-radius: 15px;
  background-clip: padding-box;
  background-color: rgba(255,255,255,0.7);
  margin: 300px 50px 150px 880px;
  padding: 35px 35px 15px 35px;
  border: 1px solid #eaeaea;
  /*水平位置 垂直位置 阴影大小 阴影颜色*/
  box-shadow: 0 0 25px #cac6c6;
}
.login_bg{
  margin-top: -70px;
  margin-left: 100px;
  z-index: 1;
  position: absolute;
}
</style>