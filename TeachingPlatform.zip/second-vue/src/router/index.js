import Vue from 'vue'
import VueRouter from 'vue-router'
import Teacher from '../views/Teacher'
import Home from '../views/Home'
import Login from '../views/Login'
import Init from '../views/Init'
import CourseManager from "../views/CourseManager";
import Information from "@/views/Information";
import Aboutus from "@/views/Aboutus";
import Course from "@/views/Course";
import Teacherteam from "@/views/Teacherteam";
import LiveCommunity from "@/views/LiveCommunity";
import SeniorOneFirst from "@/views/SeniorOneFirst";
import Register from "@/views/Register";
import Person from "@/views/Person";
import Releaselive from "@/views/Releaselive";
import Uploadvideo from "@/views/Uploadvideo";

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Init',
    component: Init,
    hidden: true
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
    hidden: true
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
    hidden: true
  },
  {
    path: '/home',
    name: '导航一',
    component: Home,
    children:[
      {
        path: '/uploadvideo',
        name: '上传视频',
        component: Uploadvideo
      },
      {
        path: '/releaselive',
        name: '发布直播信息',
        component: Releaselive
      }
    ]
  },
  {
    path: '/register',
    name: 'Register',
    component: Register,
    hidden: true
  },
  {
    path: '/person',
    name: 'Person',
    component: Person,
    hidden: true
  },
  {
    path: '/init',
    name: 'Init',
    component: Init,
    hidden: true
  },
  {
    path: '/course',
    name: 'Course',
    component: Course,
    children: [
      {
        path: '/senioronefirst',
        name: 'SeniorOneFirst',
        component: SeniorOneFirst
      }
    ]
  },
  {
    path: '/teacherteam',
    name: 'Teacherteam',
    component: Teacherteam,
    hidden: true
  },
  {
    path: '/livecommunity',
    name: 'LiveCommunity',
    component: LiveCommunity,
    hidden: true
  },
  {
    path: '/information',
    name: 'Information',
    component: Information,
    hidden: true
  },
  {
    path: '/aboutus',
    name: 'Aboutus',
    component: Aboutus,
    hidden: true
  }
]

const router = new VueRouter({
  routes
})

export default router
