If you want to run the function of uploading videos, please specify the path to store videos in the uploadvideo.vue component in Vue, 
and create a folder under the path to store your uploaded videos.
Here, I define the storage path of the video as 'C:\Users\furongzhi\Desktop\video'. The video folder is a file that stores uploaded videos.